
#include <cstdlib>
#include <iostream>
#include "Course.h"
#include "Student.h"
#include "DoublyLinkedList.h"
#include "LListWithDummyNode.h"

using namespace std;

int main() {
    int choice;
    bool quit = false;

    while (!quit) {
        cout << "1. Display the list of non-registered students." << endl;
        cout << "2. Display the list of offered courses." << endl;
        cout << "3. Display the list of registered students with the registered courses." << endl;
        cout << "4. Display the list of offered courses with the registered students." << endl;
        cout << "5. Display the registered courses for a student." << endl;
        cout << "6. Display the list of students registered in a course." << endl;
        cout << "7. Display the information related to a specific student." << endl;
        cout << "8. Register a student." << endl;
        cout << "9. Choose a student to add/drop a course for him/her." << endl;
        cout << "10. Quit the application." << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                Student student;
                Course course;
                DoublyLinkedList studentsList;
                for(int i=0; i < studentsList.getSize(); ++i){
                   student = studentsList.getElementAtPosition(i);
                   //TODO: check if student is not registered
                }
                break;
            case 2:
                cout << "List of offered courses:" << endl;
                Course course;
                course.readFile();
                break;
            case 3:
                
                break;
            case 4:
              
                break;
            case 5:
                DoublyLinkedList studentsList;
                Student student;
                string studentId
                cout << "Enter the students ID:" <<endl;
                cin >> studentId;
                studentPosition = studentsList.searchForElementByID(studentId);

                while (studentPosition == -1) {
                    cout << "Student ID " << studentId << " does not exist in the list. Try again: ";
                    cin >> studentId;
                    studentPosition = studentsList.searchForElementByID(studentId);
                }

                cout << "Student : "<< student.getID << " - " << student.getFirstName() << " " << student.getLastName() << endl;

                cout << "Courses :" <<endl;
                    //TODO: Display courses 
                break;
            case 6:
                
                break;
            case 7:
                
                break;
           case 8:
            DoublyLinkedList studentsList
            LListWithDummyNode courses
            char add;
            string studentId, courseCode;
            int studentPosition, coursePosition;

            cout << "Enter the student ID: ";
            cin >> studentId;
            studentPosition = studentsList.searchForElementByID(studentId);

            while (studentPosition == -1) {
                cout << "Student ID " << studentId << " does not exist in the list. Try again: ";
                cin >> studentId;
                studentPosition = studentsList.searchForElementByID(studentId);
            }

            do {
                cout << "Enter the course code: ";
                cin >> courseCode;
                coursePosition = courses.searchCourseById(courseCode);

                if (coursePosition != -1) {
                    cout << "Student registered in course." << endl;
                } else {
                    cout << "The course is not offered." << endl;
                }

                cout << "Do you need to add more courses [Y/N]? ";
                cin >> add;
                while (add != 'y' && add != 'Y' && add != 'n' && add != 'N') {
                    cout << "Please enter a valid option [Y/N]: ";
                    cin >> add;
                }
            } while (add == 'Y' || add == 'y');

    break;

            case 9:
                
                break;
            case 10:
                quit = true;
                cout << "Quitting application..." << endl;
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    }

    return 0;
}
