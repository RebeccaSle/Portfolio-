import { redirect } from 'next/navigation';

export default function Sites() {
  redirect('/dashboard-admin/sites/regions');
}
