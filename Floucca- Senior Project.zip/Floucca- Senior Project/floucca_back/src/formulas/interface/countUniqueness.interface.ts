export interface countUniquenessInterface {
    port: number,
    coop: number,
    region: number
}