export interface Role {
    role_id: number;
    role_code: string;
    role_name: string;
  }
  