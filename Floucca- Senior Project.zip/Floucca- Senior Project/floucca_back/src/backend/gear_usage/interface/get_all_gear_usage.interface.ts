export interface GetAllGearUsageInterface {
    gear_usage_id: number;

    fleet_senses_id: number;

    gear_code: number;

    months: number;
}