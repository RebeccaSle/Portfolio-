export interface GearUsageResInterface<T>{
    message: string,
    data?: T
}