export interface GetAllGearDetail {
    detail_id: number,
    gear_code: number,
    effort_today_id: number,
    detail_name: string,
    detail_value: string,
}

