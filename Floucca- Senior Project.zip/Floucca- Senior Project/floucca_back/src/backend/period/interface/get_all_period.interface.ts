export interface GetAllPeriodInterface {
    period_date : Date ;
    period_status : string ;
}