export interface GetCoordinatesInterface{
    landing:{
        longitude: number,
        latitude: number
    }[],
    specie_code: number
}