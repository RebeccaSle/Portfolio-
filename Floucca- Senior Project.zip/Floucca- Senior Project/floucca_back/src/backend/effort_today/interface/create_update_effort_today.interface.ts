
export interface CreateEffortTodayInterface{
    hours_fished: number,
    landing_id: number
}