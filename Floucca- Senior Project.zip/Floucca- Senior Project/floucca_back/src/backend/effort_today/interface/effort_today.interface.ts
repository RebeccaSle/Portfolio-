export interface EffortTodayInterface {
    effort_today_id: number;
    hours_fished: number;
    landing_id: number;
}

