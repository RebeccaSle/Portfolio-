export interface Backup {
    backup_id: number;
    backup_content: string;
    backup_date: Date;
  }
  