export interface BoatSuccessResponse<Data> {
  message: string;
  data?: Data;
}
