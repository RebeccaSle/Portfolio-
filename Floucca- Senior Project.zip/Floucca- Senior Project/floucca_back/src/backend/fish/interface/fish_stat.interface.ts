export interface FishStatInterface{
    specie_name: string,
    avg_length: number,
    avg_weight: number,
    avg_price: number,
    avg_quantity: number,
}