export interface GetFilteredLastWInterface {
    gear_code?: number,
    days_fished?: number,
    form: {
        form_id: number,
        port_id: number
    }
}