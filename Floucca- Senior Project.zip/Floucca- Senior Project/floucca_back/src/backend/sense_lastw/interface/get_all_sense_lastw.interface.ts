export interface GetAllSenseLastw {
    sense_lastW_id: number;
    days_fished: number;
    gear_code: number;
    form_id: number;
}
