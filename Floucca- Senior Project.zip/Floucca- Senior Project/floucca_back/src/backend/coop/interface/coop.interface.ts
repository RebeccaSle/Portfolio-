export interface CoopInterface{
    coop_code: number;
    region_code: number;
    coop_name: string;
}