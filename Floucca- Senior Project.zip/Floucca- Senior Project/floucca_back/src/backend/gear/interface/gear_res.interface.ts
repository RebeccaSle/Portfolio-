export interface GearResponse<T> {
    message: string;
    data?: T;
}