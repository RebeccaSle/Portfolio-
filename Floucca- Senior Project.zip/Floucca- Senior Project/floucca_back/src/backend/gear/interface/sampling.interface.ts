export interface SamplingInterface {
    gear_code: number,
    period: Date
}