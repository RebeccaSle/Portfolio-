export interface GetAllGearInterface {
    gear_code: number,
    gear_name: string,
    equipment_id:  string,
    equipment_name: string,
}