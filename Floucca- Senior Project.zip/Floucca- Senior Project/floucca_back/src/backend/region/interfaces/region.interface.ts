export interface Region {
    region_code: number;
    region_name: string;
  }