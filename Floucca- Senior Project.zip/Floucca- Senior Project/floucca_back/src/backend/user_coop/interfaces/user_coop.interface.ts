export interface UserCoop {
    user_coop_id: number;
    user_id: number;
    coop_code: number;
  }
  