export interface UserRole {
    user_role_id: number;
    user_id: number;
    role_id: number;
  }
  