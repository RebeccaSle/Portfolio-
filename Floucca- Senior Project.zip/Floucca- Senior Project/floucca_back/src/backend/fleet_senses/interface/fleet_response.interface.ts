export interface FleetResponse<Data>{
    message: String,
    data?: Data
}