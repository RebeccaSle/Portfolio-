export interface FleetReportInterface {
        month: number,
        freq: number,
        activeDays: number,
        gear_code: number,
        gear_name: string
}
//zedet gear code w gear name 