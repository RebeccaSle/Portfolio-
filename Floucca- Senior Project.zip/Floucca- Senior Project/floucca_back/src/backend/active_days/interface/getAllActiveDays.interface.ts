export interface GetAllActiveDaysInterface {
    active_id: number,
    period_date: Date,
    port_id: number,
    gear_code: number | null,
    active_days: number
}