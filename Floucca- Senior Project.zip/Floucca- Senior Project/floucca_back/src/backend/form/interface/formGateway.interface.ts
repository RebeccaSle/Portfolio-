export interface FormGatewayInterface{
    port_id: number;
    users:{
        user_fname: string,
        user_lname: string,
    }
}