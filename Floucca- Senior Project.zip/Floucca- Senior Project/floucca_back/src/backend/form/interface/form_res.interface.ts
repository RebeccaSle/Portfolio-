export interface FormResInterface<T>{
    message: string,
    data?: T
}