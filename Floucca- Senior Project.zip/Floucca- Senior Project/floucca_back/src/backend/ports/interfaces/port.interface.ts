export interface Port {
    port_id: number;
    port_name: string;
    coop_code: number;
  }
  