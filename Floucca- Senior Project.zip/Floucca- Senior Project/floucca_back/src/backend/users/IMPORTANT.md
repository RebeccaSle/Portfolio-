later on when aut is imlemented: 
to edit the last login logic and integrate it using tokens. 
the shared id dto is useless tbh. it creates many conflicts w ma staamalto hon. 
with love <3
bye.
becxs