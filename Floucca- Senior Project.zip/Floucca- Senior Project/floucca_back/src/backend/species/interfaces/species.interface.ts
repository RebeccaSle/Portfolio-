export interface Specie {
    specie_code: number;
    specie_name: string;
    specie_description?: string;
    specie_avg_weight: number;
    specie_avg_length: number;
  }