export enum RoleEnum {
    SUPER_ADMIN = 'super_admin',
    ADMIN = 'Administrator',
    DATA_OPERATOR = 'data_operator',
    DATA_OPERATOR_BULK = 'do_bulk'
  }
  