export interface ResponseMessage<Data>{
    message: string;
    data?: Data;
}