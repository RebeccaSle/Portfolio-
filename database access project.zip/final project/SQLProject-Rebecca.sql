-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.6.7-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping data for table electricity bill.bill: ~3 rows (approximately)
/*!40000 ALTER TABLE `bill` DISABLE KEYS */;
INSERT INTO `bill` (`SeqNo`, `MonthOfRate`, `Consumption`, `SerialNo`) VALUES
	(11, 2, 22, 'A101'),
	(12, 1, 23, 'A102'),
	(13, 7, 24, 'A103');
/*!40000 ALTER TABLE `bill` ENABLE KEYS */;

-- Dumping data for table electricity bill.client: ~5 rows (approximately)
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` (`ClientID`, `ClientName`, `CAddress`, `CPhoneNumber`) VALUES
	(1, '5', 'beirut', 71717171),
	(2, 'Tony', 'Rome', 70707070),
	(3, 'dayane', 'Texas', 78787878),
	(4, 'Lara', 'Tripoli', 78554445),
	(5, '', NULL, NULL);
/*!40000 ALTER TABLE `client` ENABLE KEYS */;

-- Dumping data for table electricity bill.employee: ~5 rows (approximately)
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` (`EmployeeId`, `EmployeeName`, `EPhoneNumber`) VALUES
	(100, 'richard', '03030303'),
	(101, 'nabil', '79797979'),
	(102, 'aziz', '01010101'),
	(103, 'karen', '03652247'),
	(104, 'Farah', '05117777');
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;

-- Dumping data for table electricity bill.monthlyrates: ~12 rows (approximately)
/*!40000 ALTER TABLE `monthlyrates` DISABLE KEYS */;
INSERT INTO `monthlyrates` (`MonthOfRate`, `Rate`) VALUES
	(1, 1000),
	(2, 870),
	(3, 4000),
	(4, 3105),
	(5, 4154),
	(6, 8989),
	(7, 8765),
	(8, 687),
	(9, 1100),
	(10, 999),
	(11, 444),
	(12, 777);
/*!40000 ALTER TABLE `monthlyrates` ENABLE KEYS */;

-- Dumping data for table electricity bill.service: ~4 rows (approximately)
/*!40000 ALTER TABLE `service` DISABLE KEYS */;
INSERT INTO `service` (`ServiceType`, `ServiceFees`) VALUES
	('home', 400),
	('offices', 2000),
	('business', 5000),
	('individuals', 200);
/*!40000 ALTER TABLE `service` ENABLE KEYS */;

-- Dumping data for table electricity bill.subscription: ~7 rows (approximately)
/*!40000 ALTER TABLE `subscription` DISABLE KEYS */;
INSERT INTO `subscription` (`SerialNo`, `ClientID`, `EmployeeId`, `StartingDate`, `ServiceType`) VALUES
	('A100', 1, 100, '2022-12-09', 'home'),
	('A101', 2, 102, '2022-11-13', 'business'),
	('A102', 3, 101, '2022-10-14', 'individuals'),
	('A103', 4, 101, '2022-01-23', 'offices'),
	('A104', 3, 100, '2022-09-08', 'business'),
	('A105', 1, 103, '2022-01-23', 'home'),
	('A106', 2, 104, '2022-03-23', 'offices');
/*!40000 ALTER TABLE `subscription` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
