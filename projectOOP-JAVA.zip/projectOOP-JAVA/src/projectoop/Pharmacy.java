package projectoop;

public class Pharmacy {


//Datafields
    private String name;
    private static int maxNbOfMedicines = 100;
    private Medicine[] medicines = new Medicine[maxNbOfMedicines];
    private int overTheCounterQuantity;
    private int prescriptionQuantity;
    private int numberOfMedicines;

    //Constructorthat takes name as parameter and sets the other datafields to 
    //their default values
    public Pharmacy(String name) {
        setName(name);
        medicines = new Medicine[maxNbOfMedicines];
        // Set the other data fields to their default values
        overTheCounterQuantity = 0;
        prescriptionQuantity = 0;
        numberOfMedicines = 0;
    }

    // set name value
    public void setName(String name) {
        this.name = name;
    }
    
    // set the maximum number of medicine
    public static void setMaxNbOfMedicines(int maxNumberOfMedicines) {
        maxNbOfMedicines = maxNumberOfMedicines;
    }

    // return the medicines array
    public Medicine[] getMedicines() {
        return medicines;
    }

    // return the presceiprion quantity
    public int getPrescriptionQuantity() {
        return prescriptionQuantity;
    }

    // return over the counter medicine's quantity
    public int getOverTheCounterQuantity() {
        return overTheCounterQuantity;
    }

    // return the number of medicines
    public int getNumberOfMedicines() {
        return numberOfMedicines;
    }

    // return the maximum number of medcines. only using the class name that this
    // method can be reached and have the value returned
    public static int getMaxNbOfMedicines() {
        return maxNbOfMedicines;
    }

    //Method addMedicine takes a variable of type Medicine
    public void addMedicine(Medicine toAdd) {
        /*
        check if array is not full, search in a for loop in the array if the 
        medicine already exist or not.
        */
        if (numberOfMedicines< maxNbOfMedicines){
            for (int i = 0; i < numberOfMedicines; i++) {
                // check if medicine exist
                if(toAdd.equals(medicines[i])){
                    System.out.println("the medicine already exists");
                    return;
                }
            }
            //add medicine to the array and increment the number of medicines
            medicines[numberOfMedicines] = toAdd;
            numberOfMedicines++;
            
            //check the type of medication in order to increment its corresponding 
            //datafield, calling the classes overTheCounter and prescription
            if (toAdd instanceof OverTheCounter)
                overTheCounterQuantity += toAdd.getQuantity();
            else
                prescriptionQuantity += toAdd.getQuantity();
        }
        else
            System.out.println("medicine could'nt be added, array is full.");

    }
    
    // method that raise or decrease price based on the percentage that is 
    //the variable that the method takes
    public void raisePrises(double percentage) {
        double percent = 1 + percentage / 100;

        //sale
        if (percentage < 0) {
            percent = 1 - Math.abs(percentage) / 100.0;
        }

        //setting the new medicine prices 
        for (int i = 0; i < numberOfMedicines; i++) {
            medicines[i].setPrice(medicines[i].getPrice() * percent);
        }
    }

   // method taking name as parameter in order to search for medicines it if
   //present or not and return the index at witch the medicine is present
   public int[] searchByName(String name) {
        int medCounted = 0;
        int[] tempIn = new int[numberOfMedicines];

        //To find the size of the index array
        for (int i = 0; i < numberOfMedicines; i++) {
            if ((medicines[i].getName().equals(name.toLowerCase()))
                    || (medicines[i].getName().equals(name.toUpperCase()))) {
                tempIn[medCounted++] = i;
            }
        }

        int[] index = new int[medCounted];
        //Add the indices to array index to be returned
        for (int i = 0; i < medCounted; i++) {
            index[i] = tempIn[i];
        }
        
        return index;
        }

   // take name and dose as parameters and search for them in the array and return
   // the position
    public int searchByNameAndDose(String name, int dose) {
       //search in a for loop for the medicine and if present return at what index
        for (int i = 0; i < numberOfMedicines; i++) {
            if (medicines[i].getName().equalsIgnoreCase(name)
                    && medicines[i].getDose() == dose) {
                return i;
            }
            // if not present, return -1 
        }
        return -1;
    }

    public int[] searchByComposition(String composition) {
        int[] compFound = new int[numberOfMedicines];
        int compCounted = 0;

        for (int i = 0; i < numberOfMedicines; i++) {
            if (medicines[i].getComposition().equalsIgnoreCase(composition)) {
                compFound[compCounted++] = i;
            }
        }

        int[] index = new int[compCounted];
        for (int i = 0; i < compCounted; i++) {
            index[i] = compFound[i];
        }
        return index;
    }

    public void sellMedicine(String name, int dose, int quantity) {
        int indexOfMed = searchByNameAndDose(name, dose);

        if (indexOfMed == -1) {
            System.out.println("The medication is not found.");
            return;
        }
        
        else if (quantity > medicines[indexOfMed].getQuantity()) {
            System.out.println("Available quantity is not enough. "
                    + "The array medicines remains unchanged.");
            return;
        }
        
        medicines[indexOfMed].setQuantity(medicines[indexOfMed].getQuantity() - quantity);

        if (medicines[indexOfMed] instanceof Prescription) {
            prescriptionQuantity -= quantity;
        } else {
            overTheCounterQuantity -= quantity;
        }

        System.out.println("Selling is successful!");

    }

    // take name dose and quantity as parameters and restock the medicines 
    //and return true if restock happens
    public boolean restock(String name, int dose, int quantity) {
        
        // call method search by name and find the medicne
        int restock = searchByNameAndDose(name, dose);

        // if not present, it cant be restocked
        if (restock == -1) {
            return false;
        }

        // if medicine found, restock calling setQuantity and increment quantity
        medicines[restock].setQuantity(medicines[restock].getQuantity() + quantity);

        // increment prescription or over the counter quantity depending on the
        // medication
        if (medicines[restock] instanceof OverTheCounter) {
            overTheCounterQuantity += quantity;
        } else {
            prescriptionQuantity += quantity;
        }

        return true;
    }
    
    // display the corresponding information in a certain order
    public String toString() {
        return "Pharmacy: " +name+ "\nNumber of medicines: " +numberOfMedicines+
                "\nOver the counter quantity: " +overTheCounterQuantity+
                "\nPrescription quantity: "+prescriptionQuantity; 
    }

}









