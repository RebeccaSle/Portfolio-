package projectoop;

public class Prescription extends Medicine {

//Datafields  
    private String drSpecialization;

    // takes as parameter name composition dose and drSpecialization 
    public Prescription(String name, String composition, int dose,
           String drSpecialization) {
        super(name, composition, dose);
        setDrSpecialization(drSpecialization);
    }
    
    //takes as parameter all medicine datafields 
    public Prescription(String name, String composition, int dose, double price,
            int quantity, String drSpecialization) {
        
        //call the parent constructor to initialize the data fields of the 
        //Medicine class before initializing the drSpecialization data field 
        super(name, composition, dose, price, quantity);
        setDrSpecialization(drSpecialization);
    }
    
    //return the dr specialization
    public String getDrSpecialization() {
        return drSpecialization;
    }

    //set value for the dr specialization datafield, takes drSpecialization as variable
    public void setDrSpecialization(String drSpecialization) {
        this.drSpecialization = drSpecialization;
    }

    //display all the information, including the toString method in medicine class
    @Override
    public String toString() {

        return "Prescription: \n" + super.toString() + "\nDoctor Specialization: "
                + drSpecialization;
    }

}
