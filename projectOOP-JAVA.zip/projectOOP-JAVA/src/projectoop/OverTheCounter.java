package projectoop;

public class OverTheCounter extends Medicine {

//Datafield
    private int minAge;
    
    /*
    arg constructor that takes name, composition dose and min age as parameters
    */
    public OverTheCounter(String name, String composition, int dose, int minAge){
        super(name, composition, dose, 10.0, 0);
        setMinAge(minAge);
    }
    
    // constructor that takes all datafields of medicine, and minAge as parameters
    public OverTheCounter(String name, String composition, int dose, double price,
            int quantity, int minAge) {
       super(name, composition, dose, price, quantity);
       setMinAge(minAge);
    }

    // return the value of minAge
    public int getMinAge() {
        return minAge;
    }

    // set minAge for the medicine 
    public void setMinAge(int minAge) {
     
        // set min age to default value if the entered one is negative   
        if (minAge > 0) {
            this.minAge = minAge;
        } else {
            this.minAge = 18;
        }
    }
    
    // display the datafields 
    public String toString(){
        return "Over the counter: \n" + super.toString() + "\nMinimum age: " +
              + minAge;
    }
}