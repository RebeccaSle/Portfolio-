package projectoop;

public class Medicine {

//Define datafields
    private String name;
    private String composition;
    private int dose; // in mg
    private double price;
    private int quantity;

//Constructors and methods
    
    /*
    constructor that takes name, composition and dose as parameter and set as 
    default the other datafields
    */
    public Medicine(String name, String composition, int dose) {
        this(name, composition, dose, 10.0, 0);
    }
    
    //method that take as parameter all the datafields to set their values
    public Medicine(String name, String composition, int dose, double price,
            int quantity) {
        setName(name);
        setComposition(composition);
        setDose(dose);
        setPrice(price);
        setQuantity(quantity);
    }

    //takes name as parameter and set its value
    public void setName(String name) {
        //Convert the name to lower case 
        this.name = name.toLowerCase();
    }
    
    // takes composition as parameter and set its value
    public void setComposition(String composition) {
        // convert the composition to lower case 
        this.composition = composition.toLowerCase();
    }

    // takes dose as parameter and set its value
    public void setDose(int doses) {
        //The dose must be positive, else set to default value.
        if (doses > 0) {
            dose = doses;
        } else {
            dose = 1000;
        }

    }

    // takes prices as parameter and set its value
    public void setPrice(double prices) {
        //The price must be positive, esle set to default value.
        if (prices > 0) {
            price = prices;
        } else {
            price = 10.0;
        }

    }

    // takes quantity as parameter and set its value
    public void setQuantity(int quantity) {
        //Quantity must be positive, else set to zero.
        this.quantity = Math.max(0, quantity);
    }

    // return composition
    public String getComposition() {
        return composition;
    }

    // return dose
    public int getDose() {
        return dose;
    }

    //return name
    public String getName() {
        return name;
    }

    //return price
    public double getPrice() {
        return price;
    }

    // return quantity
    public int getQuantity() {
        return quantity;
    }

    //method to demonstrate the df values in a specific way
    public String toString() {
        return "Name: " + name + "\nComposition: " + composition + "\nDose: "
                + dose + " mg \nPrice: " + price + "\nQuantity: " + quantity;
    }

    //takes object as parameter and compares if two objects have the same name 
    // and dose
    public boolean equals(Object obj) {
        // Cast the object to Medicine
        Medicine other = (Medicine) obj;
        // Compare name and dose
        return this.name.equals(other.name) && this.dose == other.dose;
    }
}
