/* Name: Rebecca Sleiman 
Date: 14/4/2023
OOP project: pharmacy
create a pharmacy and add medicines and create many methods corresponding to
the pharmacy roles, taking into consideration dose, prescriptions, min age of
medicine consumption etc. 
5 classes including the main are created:
 Medicine (parent), prescription and overTheCounter(child), and pharmacy. 
*/
package projectoop;

import java.util.Scanner;

public class ProjectOOP {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Pharmacy pharma = new Pharmacy("pharma");
        int choice;

        System.out.println("Welcome to \" myPharma \" pharmacy system.");
        System.out.println("------------------------------------------");

        /* switch case to display the menu options calling the method menu
        and stop execution and exit the for loop when 8 is entered 
        each time a case is entered it takes us to its corresponding method.
        */
        do {
            choice = menu();

            switch (choice) {

                case 1:
                    addMedicine(pharma);
                    break;
                case 2:
                    searchByName(pharma);
                    break;
                case 3:
                    searchByComposition(pharma);
                    break;
                case 4:
                    sell(pharma);
                    break;
                case 5:
                    restock(pharma);
                    break;
                case 6:
                    displayAllMedicine(pharma);
                    break;
                case 7:
                    System.out.println(pharma);
                    break;
                case 8:
                    System.out.println("Exiting...");
                    break;
            }
            System.out.println("-----------------------------------------");
        } while (choice != 8);

    }

    //This method displays the menu to the user and returns the user's choice.
    public static int menu() {
        Scanner input = new Scanner(System.in);
        int userChoice;
        System.out.println("""
                           1- Add a new medicine 
                           2- Search for a medicine by name 
                           3- Search for a medicine by composition 
                           4- Sell a medicine 
                           5- Restock a medicine 
                           6- Display all medicines 
                           7- Display information 
                           8- Exit""");
        System.out.println("Enter your choice (between 1 and 8):");
        userChoice = input.nextInt();
        return userChoice;
    }
    
    /*Case 1 method
    This method prompts the user to enter the information of a new medicine,
    including its name, composition, dose, quantity, price, and whether it's 
    over the counter or prescription medicine.If the medicine is over the counter, 
    the user also needs to enter the minimum age required to use it. 
    If the medicine is prescription, the user needs to enter the doctor specialization. 
    The method then creates a new instance of either the OverTheCounter or
    Prescription class, depending on the type of medicine, and adds it to the pharmacy.
    */
    private static void addMedicine(Pharmacy pharma) {
        Scanner input = new Scanner(System.in);
        char prescription;
        String name, composition, specialization;
        int dose, quantity, minAge;
        double price;
        
        //print and save the output of the demanded information 
        System.out.println("Enter the information of the new medicine: ");
        System.out.print("");
        System.out.print("""
                           Choose O or o for over the counter medicine and p or P for 
                           prescription medicine:""");
        prescription = input.next().charAt(0);

        System.out.print("name: ");
        name = input.next();

        System.out.print("composition: ");
        composition = input.next();

        System.out.print("dose: ");
        dose = input.nextInt();

        System.out.print("quantity:");
        quantity = input.nextInt();

        System.out.print("price: ");
        price = input.nextDouble();
        
        /*switch case to display and increment the number of medicine based on 
        whether it is an over the counter or prescription medicine.
        */
        switch (prescription) {
            case 'o':
            case 'O':
                System.out.print("Enter the minimum Age for this medicine: ");
                minAge = input.nextInt();

                pharma.addMedicine(new OverTheCounter(name, composition, dose,
                        price, quantity, minAge));
                break;
            case 'p':
            case 'P':
                System.out.println("Enter the doctor specialization for this"
                        + "medicine");
                specialization = input.next();

                pharma.addMedicine(new Prescription(name, composition, dose,
                        price, quantity, specialization));
                break;
            default:
                System.out.println("Wrong type of medicine.");
                System.out.println("No medicine added.");
                return;
        }
        System.out.println("The new medicine is added successfully!");
    }

    /*Case 2 method
    This method prompts the user to enter the name of a medicine and searches for
    it in the pharmacy. It then displays all the medicines with the matching name,
    along with their information
    */
    private static void searchByName(Pharmacy pharma) {
        Scanner input = new Scanner(System.in);
        String medName;

        System.out.println("Enter the name of medicine to be found: ");
        medName = input.next();

        int[] index = pharma.searchByName(medName);

        System.out.println(index.length + " medicine found matching this name.");

        //search for the medicine in the for loop and display its details
        for (int i = 0; i < index.length; i++) {
        System.out.printf("%d- %s", i + 1, 
                pharma.getMedicines()[index[i]].toString());  
        System.out.println("");
        System.out.println("\n---------------------------------------\n");
        }
    }

    /*Case 3 method
    This method prompts the user to enter the composition of a medicine and 
    searches for it in the pharmacy. It then displays all the medicines with the 
    matching composition.
    */
    private static void searchByComposition(Pharmacy pharma) {
        Scanner input = new Scanner(System.in);
        String composition;

        System.out.println("Enter the composition to be found: ");
        composition = input.next();

        //calling method searchByComposition to find the corresponding medicine
        int[] index = pharma.searchByComposition(composition);

        System.out.println(index.length + " medicine found matching this "
                + "composition.");

        //search for the medicine in the for loop and display its details
        for (int i = 0; i < index.length; i++) {
            System.out.printf("%d- %s", i + 1, 
                    pharma.getMedicines()[index[i]].toString());
            System.out.println("\n--------------------------------------");
        }
    }

    /*Case  4 method
    enter the name, dose, and quantity of a medicine to sell. 
    It then updates the quantity of the medicine in the pharmacy.
    */
    private static void sell(Pharmacy pharma) {
        Scanner input = new Scanner(System.in);
        String name;
        int dose, quantity;

        System.out.println("Enter the name of the medicine");
        name = input.next();

        System.out.println("Enter the dose: ");
        dose = input.nextInt();

        System.out.println("Enter the quantity: ");
        quantity = input.nextInt();

        pharma.sellMedicine(name, dose, quantity);
        
        System.out.println("Selling successful");
    }

    //Case 5 method
   // enter the name, dose, and quantity of a medicine to restock. 
    
    private static void restock(Pharmacy pharma) {
        Scanner input = new Scanner(System.in);
        String name;
        int dose, quantity;

        System.out.println("Enter the name of the medicine");
        name = input.next();

        System.out.println("Enter the dose: ");
        dose = input.nextInt();

        System.out.println("Enter the quantity: ");
        quantity = input.nextInt();

        //updates the quantity of the medicine in the pharmacy accordingly.
        pharma.restock(name, dose, quantity);
        System.out.println("Restock Successful");

    }
    
    //Case 6 method  
    //displays all the medicines in the pharmacy, along with their information.
    private static void displayAllMedicine(Pharmacy pharma) {
        for (int i = 0; i < pharma.getNumberOfMedicines(); i++) {
       System.out.printf("Medicine %d: %s\n", i + 1, 
               pharma.getMedicines()[i].toString());

            System.out.println("----");
        }
    }

}
