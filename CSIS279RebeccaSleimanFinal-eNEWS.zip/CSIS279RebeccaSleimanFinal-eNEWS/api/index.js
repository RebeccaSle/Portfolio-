const express = require('express');
const app = express();
const PORT = 3001;
const path = require('path');
const cors = require('cors');
const http = require('http'); 
const socketIO = require('socket.io');
const server = http.createServer(app); 
const userRoutes = require('./Routes/userRoute'); 
const newsRoutes = require('./Routes/newsRoute'); 
const categoryRoutes = require('./Routes/categoryRoute');
const authorRoute = require('./Routes/authorRoute');
const videoStreamHandler = require('./socket/videoStreamHandler');

// Middleware to parse JSON 
app.use(express.json());
app.use(express.urlencoded({ extended: true })); // URL
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

const io = socketIO(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST'],
  },
});

app.use(cors());

// Video stream handler for WebSockets
videoStreamHandler(io);

// Test route to confirm server setup
app.get('/test-direct', (req, res) => {
  res.send('Direct test route is working');
});

// Root route handler
app.get('/', (req, res) => {
  res.send('Welcome to the User Management API');
});

app.use('/api/users', userRoutes);
app.use('/api/news', newsRoutes);
app.use('/api/category', categoryRoutes);
app.use('/api/author', authorRoute); 

// Start the server
server.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
