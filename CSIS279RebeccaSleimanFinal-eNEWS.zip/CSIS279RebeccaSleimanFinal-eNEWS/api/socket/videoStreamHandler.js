// Note that my code include all the console statements that I used for debugging purposes
//I left them because I did not have time to pass by all files and clean them
const videoStreamHandler = (io) => {
  let broadcaster = null;

  io.on("connection", (socket) => {
    console.log("A client connected:", socket.id);

    //broadcaster joining
    socket.on("broadcaster", () => {
      broadcaster = socket.id;
      io.emit("broadcaster", broadcaster); 
      io.emit("streamStarted", { broadcasterId: broadcaster });  
      console.log("New broadcaster connected:", broadcaster);  
      console.log("Stream started event emitted");
    });

    // watcher joining the broadcast handled here
    //broadcaster is notified whenever new watcher entered, i have to edit 
    //so the name appear not only socket id
    socket.on("watcher", () => {
      if (broadcaster) {
        io.to(broadcaster).emit("watcher", socket.id); 
        console.log(`Watcher connected: ${socket.id}`);
      } else {
        console.log("No broadcaster available for watcher:", socket.id);
      }
    });

    //  WebRTC offer from broadcaster, answer and ice candidate logic code
    socket.on("offer", (data) => {
      const { offer, watcherId } = data;
      io.to(watcherId).emit("offer", offer); 
      console.log(`Offer sent from ${socket.id} to ${watcherId}`);
    });

    socket.on("answer", (data) => {
      const { answer, broadcasterId } = data;
      io.to(broadcasterId).emit("answer", answer); 
      console.log(`Answer sent from ${socket.id} to ${broadcasterId}`);
    });

    // a google stun server is used that handles the following
    //  ICE candidate
    socket.on("ice-candidate", (data) => {
      const { candidate, targetId } = data;
      io.to(targetId).emit("ice-candidate", candidate); 
      console.log(`ICE candidate sent from ${socket.id} to ${targetId}`);
    });

    // stop stream (stream ended and display it 
    socket.on("stopBroadcast", () => {
      if (broadcaster) {
        io.emit("streamEnded", { broadcasterId: broadcaster });
        console.log("Stream ended by broadcaster:", broadcaster);
        broadcaster = null; // Reset broadcaster if they stop streaming
        io.emit("broadcaster-disconnected");
        console.log("Broadcaster disconnected");
      }
    });

    socket.on("disconnect", () => {
      socket.broadcast.emit("peer-disconnected", socket.id); 
      console.log("Client disconnected:", socket.id);
      if (socket.id === broadcaster) {
        broadcaster = null; // Reset broadcaster  disconnected
        io.emit("broadcaster-disconnected");
        console.log("Broadcaster disconnected");
      }
    });
  });
};

module.exports = videoStreamHandler;
