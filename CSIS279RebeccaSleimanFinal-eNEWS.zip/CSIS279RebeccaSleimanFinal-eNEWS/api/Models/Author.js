const { DataTypes } = require('sequelize');
const sequelize = require('../Config/DBConfig');

/**
 * Author Model
 * Represents the authors in the database.
 */
const Author = sequelize.define('Author', {
    authorid: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false,
    },
    authorname: {
        type: DataTypes.STRING(255), 
        allowNull: false, 
    },
}, 
{
    tableName: 'author', 
    timestamps: false, 
});


module.exports = Author;
