const { Sequelize, DataTypes } = require('sequelize'); // Import Sequelize and DataTypes
const sequelize = require('../Config/DBConfig');


const Users = sequelize.define('Users', {
    userid: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false,
    },
    username: {
        type: DataTypes.STRING,
        allowNull: false, 
    },
    email: {
        type: DataTypes.STRING,
        allowNull: true, 
        unique: true,
    },
    password: {
        type: DataTypes.STRING,
        allowNull: false, 
    },
    role: {
        type: DataTypes.ENUM('admin', 'user'),
        defaultValue: 'user',
        allowNull: true, 
    },
    user_phone: {
        type: DataTypes.BIGINT,
        allowNull: true, 
        unique: true, 
    },
    joined_on: {
        type: DataTypes.DATE, 
        allowNull: false,
        defaultValue: DataTypes.NOW 
    },
}, 
{
    tableName: 'users', 
    timestamps: false, 
}
);

module.exports = Users;
