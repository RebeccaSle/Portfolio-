const { DataTypes } = require('sequelize');
const sequelize = require('../Config/DBConfig');

/**
 * Category Model
 * Represents the categories in the database.
 */
const Category = sequelize.define('Category', {
    categoryid: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false, 
    },
    categoryname: {
        type: DataTypes.STRING(255), 
        allowNull: false, 
    },
}, 
{
    tableName: 'category', 
    timestamps: false, 
});


module.exports = Category;
