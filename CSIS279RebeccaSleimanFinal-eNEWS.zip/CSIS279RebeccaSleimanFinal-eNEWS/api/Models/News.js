// models/News.js
const { DataTypes } = require('sequelize');
const sequelize = require('../Config/DBConfig');

/**
 * News Model
 * Represents the news articles in the database.
 */
const News = sequelize.define('News', {
    newsid: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false,
    },
    title: {
        type: DataTypes.STRING,
        allowNull: false, 
    },
    content: {
        type: DataTypes.TEXT,
        allowNull: false,
    },
    categoryid: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    authorid: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    image: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    publish_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    is_active: {
        type: DataTypes.BOOLEAN,
        defaultValue: true,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
        defaultValue: DataTypes.NOW,  
    },
    click_count: { 
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0,
    },
}, 
{
    tableName: 'news', 
    timestamps: false, 
});


module.exports = News;
