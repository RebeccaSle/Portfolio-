const Author = require ("../Models/Author");

const getAllAuthors = async () => {
    try {
        const authors = await Author.findAll({
            attributes: ['authorid', 'authorname'],
        });
        return authors;
    } catch (error) {
        console.error('Error fetching all authors:', error);
        throw new Error('Failed to fetch authors');
    }
}

const getAuthorById = async (authorid) => {
    try {
        const author = await Author.findOne({
            where: { authorid: authorid }, 
            attributes: ['authorid', 'authorname'], 
        });
        if (!author) {
            throw new Error(`Author with the ID ${authorid} not found.`);
        }
        return author;
    } catch (error) {
        console.error('Error fetching author by ID:', error);
        throw new Error('Failed to fetch author by ID');
    }
}

const deleteAuthor = async (id) => {
    try {
        const author = await Author.findByPk(id); 
        if (!author) {
            throw new Error(`Author with the ID ${id} not found.`);
        }
        await author.destroy(); 
        return author; 
    } catch (error) {
        console.error('Error deleting author:', error);
        throw new Error('Failed to delete author');
    }
}

const createAuthor = async (authorname) => {
    try {

        if (!authorname) {
            throw new Error('Author name is required.'); 
        }

        const newAuthor = await Author.create({authorname});

        return newAuthor.toJSON(); 
    } catch (err) {
        console.error('Error creating author:', err);
        throw new Error('Failed to create author'); 
    }
}

const updateAuthor = async (authorid) => {
    try {
        if (!authorid) {
            throw new Error('Author ID is required.'); 
        }


        const author = await Author.findByPk(authorid);

        if (!author) {
            throw new Error(`Author not found with ID: ${authorid}`); 
        }

        await author.save(); 
        return author.toJSON(); 

    } catch (err) {
        console.error('Error updating author:', err);
        throw new Error('Failed to update author'); 
    }
};


module.exports = {
    getAllAuthors,
    getAuthorById,
    deleteAuthor,
    createAuthor,
    updateAuthor
}