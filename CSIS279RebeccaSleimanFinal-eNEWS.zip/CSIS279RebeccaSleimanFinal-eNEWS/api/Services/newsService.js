const News = require ("../Models/News");
const Category = require("../Models/Category")
const Author = require("../Models/Author")
const { Op } = require("sequelize"); 


const getAllNews = async (page = 1, pageSize = 60) => {
    try {
        const offset = (page - 1) * pageSize; 

        const news = await News.findAll({
            attributes: [
                ['newsid', "ID"], 
                ['title', 'title'],
                ['content', "Content"], 
                ['categoryid', "CategoryID"],
                ['authorid', "AuthorID"], 
                ['image', "Image"], 
                ['publish_at', "PublicationTime"], 
                ['is_active', "Active"], 
                ['click_count', "ClickCount"]
            ],
            limit: pageSize, 
            offset: offset 
        });

        return news;
    } catch (error) {
        console.error('Error retrieving articles:', error);
        throw new Error('Failed to retrieve news');
    }
};

const getNewsById = async (id) => {
    try{
        const news = await News.findByPk(id);
        if (news) {
            return news.toJSON();
        }
        return "News not found";
    }catch(err){
        console.error('Error retrieving News by ID:',err);
        throw new Error('Failed to retrieve news');
    }
};

const createNews = async (newsData) => {
    try {
        const { title, content, categoryid, authorid, image, publish_at, is_active } = newsData;

        if (!title || !content || !categoryid || !authorid) {
            throw new Error("Title, content, category ID, and author ID are required.");
        }

        const newNews = await News.create({
            title,
            content,
            categoryid,
            authorid,
            image: image || null,  
            publish_at: publish_at || new Date(), 
            is_active: is_active !== undefined ? is_active : 1,  
            created_at: new Date() 
        });

        return newNews.toJSON();  
    } catch (err) {
        console.error('Error creating news:', err);
        throw new Error('Failed to create news');
    }
};


const getNewsByCategoryId = async (categoryid) => {
    try {
        const news = await News.findAll({
            where: {
                categoryid: categoryid, 
                is_active: 1 
            },

            order: [['click_count', 'DESC']] 
        });
        return news;
    } catch (error) {
        console.error('Error fetching news by category ID:', error);
        throw new Error('Failed fetching news by category ID.');
    }
};

const updateNews = async (id, title, content, categoryid, authorid, image, is_active) => {
    try {
        const existingNews = await News.findOne({
            where: { newsid: id }
        });

        if (!existingNews) {
            throw new Error('News article not found');
        }

        await News.update({
            title: title !== undefined ? title : existingNews.title,
            content: content !== undefined ? content : existingNews.content,
            categoryid: categoryid !== undefined ? categoryid : existingNews.categoryid,
            authorid: authorid !== undefined ? authorid : existingNews.authorid,
            image: image !== undefined ? image : existingNews.image,
            is_active: is_active !== undefined ? is_active : existingNews.is_active,
        }, {
            where: { newsid: id }
        });

        const updatedNews = await News.findOne({
            where: { newsid: id }
        });

        return updatedNews; 
    } catch (error) {
        console.error('Error updating news article:', error);
        throw new Error('Failed to update news article');
    }
};


const deleteNews = async (id) =>{
    try{
        const news = await News.findByPk(id);
        if(!news){
            throw new Error(`News with the id ${id} is not found.`);
        }
        const deletedNews = await news.destroy();
        return deletedNews;
    }catch(error){
        console.error('Error deleting news:', error);
        throw new Error('Failed to delete news');
    }
};



const getNewsByAuthorId = async (authorid) => {
    try {
        const news = await News.findAll({
            where: {
                authorid: authorid
            },
            include: [
                { model: Author, attributes: ['authorname'] }
            ]
        });
        return news;
    } catch (error) {
        console.error('Error fetching news by author ID:', error);
        throw new Error('Failed fetching news by author ID');
    }
};

const getNewsByActivity = async (isActive) => {
    try {
        const news = await News.findAll({
            where: {
                is_active: isActive
            },
        });

        return news.length > 0 ? news : []; 
    } catch (error) {
        console.error('Error fetching news by activity status:', error);
        throw new Error('Failed fetching news by activity status');
    }
};

const getNewsByClicks = async () => {
    try {
        const news = await News.findAll({
            where: {
                is_active: 1 
            },
            order: [['click_count', 'DESC']], 
            include: [
                { model: Author, attributes: ['authorname'] },
                { model: Category, attributes: ['categoryname'] }
            ]
        });
        return news;
    } catch (error) {
        console.error('Error fetching news by click count:', error);
        throw new Error('Failed fetching news by click count');
    }
};

const updateActivity = async (newsid, isActive) => {
    try {
        console.log('Attempting to update activity for newsid:', newsid, 'to is_active:', isActive);

        // Attempting to update
        const updated = await News.update(
            { is_active: isActive },
            { where: { newsid: newsid } }
        );

        console.log('Update result for newsid', newsid, ':', updated);

        if (updated[0] === 0) {
            console.error('No records updated. Checking if the newsid exists.');
            const existingNews = await News.findOne({ where: { newsid: newsid } });
            if (!existingNews) {
                console.error('No news found with newsid:', newsid);
            }
            throw new Error('No news article found to update activity status');
        }

        return `News activity updated successfully to ${isActive ? 'active' : 'inactive'}`;
    } catch (error) {
        console.error('Error updating news activity:', error.message);
        throw new Error('Failed to update news activity');
    }
};

const getPublishedNews = async () => {
    try {
        const now = new Date();
        const utcNow = now.toISOString();  

        const publishedNews = await News.findAll({
            where: {
                [Op.or]: [
                    { publish_at: { [Op.lte]: utcNow } },  
                    { publish_at: null }  
                ]
            },
            order: [['publish_at', 'DESC']] 
        });

        return publishedNews.length > 0 ? publishedNews : [];
    } catch (error) {
        console.error('Error fetching published news:', error);
        throw new Error('Failed to fetch published news.');
    }
};

const getUpcomingNews = async () => {
    try {
        const now = new Date();
        
        const upcomingNews = await News.findAll({
            where: {
                publish_at: {
                    [Op.gt]: now 
                }
            },
            order: [['publish_at', 'ASC']] 
        });

        return upcomingNews.length > 0 ? upcomingNews : [];
    } catch (error) {
        console.error('Error fetching upcoming news:', error);
        throw new Error('Failed to fetch upcoming news.');
    }
};

module.exports = {
    getAllNews,
    getNewsById, 
    createNews,
    getNewsByCategoryId,
    updateNews,
    deleteNews,
    getNewsByAuthorId,
    getNewsByActivity,
    getNewsByClicks,
    updateActivity,
    getPublishedNews,
    getUpcomingNews
};