const User = require("../Models/User");
const bcrypt = require("bcrypt");
const saltRounds = 10;
require("dotenv").config();
const jwt = require("jsonwebtoken");

const createUser = async (username, email, password, phone) => {
    try {
        const hashedPassword = await bcrypt.hash(password, saltRounds);
        console.log(`Hashed Password: ${hashedPassword}`);
        
        const newUser = await User.create({

            username: username,
            email: email,
            password: hashedPassword,
            user_phone: phone,
            joined_on: new Date(),
        });

        console.log(`User created successfully: ${JSON.stringify(newUser)}`);

        return newUser;
    } catch (error) {
        console.error('Error creating user:', error);
        throw new Error('Failed to create user');
    }
};

const getAllUsers = async (page = 1, pageSize = 50) => {
    try {
        const offset = (page - 1) * pageSize; 

        const users = await User.findAll({
            attributes: [
                ['userid', "ID"], 
                ['email', 'Email'], 
                ['username', 'Username'], 
                ['user_phone', 'Phone'], 
                ['role', 'Role'], 
                ['joined_on', 'Joined_on']
            ],
            limit: pageSize, 
            offset: offset 
        });
        console.log('Retrieved users:', users); 

        return users;
    } catch (error) {
        console.error('Error retrieving users:', error);
        throw new Error('Failed to retrieve users');
    }
};


const getUserById = async (userid) => {
    try {
        const user = await User.findByPk(userid);
        if (user) {
            return user.toJSON();
        }
        return "User not found";
    } catch (error) {
        console.error('Error retrieving user by ID:', error);
        throw new Error('Failed to retrieve user');
    }
};

const getUserByEmail = async (email) => {
    try {
        const user = await User.findOne({ where: { email: email } });
        return user || null;
    } catch (err) {
        throw new Error(`Error in finding the user with the email ${email}`);
    }
};

const getUserRole = async (userId) => {
    try {
        const user = await User.findByPk(userId, {
            attributes: ['role'],  
        });
        return user ? user.role : null;
    } catch (error) {
        console.error(`Error fetching role for user ID ${userId}:`, error);
        throw new Error('Failed to fetch user role');
    }
};

const getUsersByRole = async (role) => {
    try {
        const users = await User.findAll({
            where: { role: role }
        });
        return users;
    } catch (error) {
        console.error(`Error retrieving users with role ${role}:`, error);
        throw new Error(`Failed to retrieve users with role ${role}`);
    }
};

const updateUser = async (id, { username, email, oldPassword, newPassword, user_phone }) => {
    try {
        const user = await User.findByPk(id);
        if (!user) {
            throw new Error("User not found");
        }

        if (newPassword) {
            const isMatch = await bcrypt.compare(oldPassword, user.password);
            if (!isMatch) {
                return { error: "Old password is incorrect" };
            }

            user.password = await bcrypt.hash(newPassword, saltRounds);
        }

        user.username = username || user.username;
        user.email = email || user.email;
        user.user_phone = user_phone || user.user_phone;

        await user.save();
        return user.toJSON(); 
    } catch (error) {
        console.error('Error updating user:', error);
        throw new Error('Failed to update user');
    }
};

const deleteUser = async (id) => {
    try {
        const user = await User.findByPk(id);
        
        if (!user) {
            return 0;
        }

        const result = await user.destroy();
        return result ? 1 : 0; 
       
    } catch (error) {
        console.error('Error deleting user:', error.message);
        throw new Error('Failed to delete user');
    }
};

const updatePasswordService = async (userid, newPassword) => {
    try {
        const user = await User.findOne({ where: { userid } });

        if (!user) {
            return { error: 'User not found' };
        }

        const hashedPassword = await bcrypt.hash(newPassword, 10); 

        const updatedUser = await user.update({ password: hashedPassword });

        return {
            userid: updatedUser.userid,
            username: updatedUser.username,
            email: updatedUser.email,
            role: updatedUser.role
        };
    } catch (error) {
        console.error('Error updating password:', error);
        throw new Error('Failed to update password');
    }
};




module.exports = {
    createUser,
    getAllUsers,
    getUserById,
    updateUser,
    deleteUser,
    getUserByEmail,
    getUserRole,
    getUsersByRole,
    updatePasswordService
};
