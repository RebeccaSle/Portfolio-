const Category = require ("../Models/Category");

const getAllCategories = async () => {
    try {
        const categories = await Category.findAll({
            attributes: ['categoryid', 'categoryname'], 
        });
        return categories;
    } catch (error) {
        console.error('Error fetching all categories:', error);
        throw new Error('Failed to retrieve categories');
    }
}

const getCategoryById = async (id) => {
    try {
        const category = await Category.findByPk(id, {
            attributes: ['categoryid', 'categoryname'] 
        });

        if (!category) {
            throw new Error(`Category with ID ${id} not found`);
        }

        return category;
    } catch (error) {
        console.error('Error fetching category by ID:', error);
        throw new Error('Failed to fetch category by ID');
    }
}

const deleteCategory = async(id) => {
    try{
        const category = await Category.findByPk(id);
        if(!category){
            throw new Error(`category with the id ${id} is not found.`);
        }
        const deletedCategory = await category.destroy();
        return deletedCategory;
    }catch(error){
        console.error('Error deleting category:', error);
        throw new Error('Failed to delete category');
    }
}

const createCategory = async(categoryname) => {
    try {
    
        if (!categoryname) {
            throw new Error("Category name is required.");
        }

        const newCategory = await Category.create({categoryname});

        return newCategory.toJSON(); 
    } catch (error) {
        console.error("Error creating category:", error);
        throw new Error("Failed to create category");
    }
}

const updateCategory = async (id, categoryname) => {
    try {
        const existingCategory = await Category.findByPk(id);
        if (!existingCategory) {
            throw new Error(`Category with the ID ${id} not found.`);
        }

        const updatedCategory = await existingCategory.update({
            categoryname: categoryname !== undefined ? categoryname : existingCategory.categoryname,
        });

        return updatedCategory.toJSON();
    } catch (error) {
        console.error("Error updating category:", error);
        throw new Error("Failed to update category");
    }
}

module.exports= {
    getAllCategories,
    getCategoryById,
    deleteCategory,
    createCategory,
    updateCategory
}