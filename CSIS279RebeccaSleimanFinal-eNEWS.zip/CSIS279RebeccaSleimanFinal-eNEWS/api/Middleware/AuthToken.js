const jwt = require("jsonwebtoken");
require("dotenv").config()

const authenticateToken = (req, res, next) => {
    const authHeader = req.header("authorization");
    const token = authHeader && authHeader.split(" ")[1];

    if(token == null){
        return res.status(401).json({message: "Token not found"});
    }

    try{
        const user = jwt.verify(token, process.env.JWT_SECRET);
        req.user = user;
        next();
        }catch (error){
            console.error("Error verifying token", error);
            res.status(403).json({message:"invalid token"});
        }
};

module.exports = authenticateToken;