const { check } = require('express-validator');

const insertUserValidation = [
    check('userid').isInt().withMessage('User ID must be an integer'),
    check('username').notEmpty().withMessage('Username is required').isString().withMessage('Username must be a string'),
    check('email').isEmail().withMessage('Invalid Email Format'),
    check('password').notEmpty().withMessage('Password is required').isLength({ min: 8 }).withMessage('Password must be at least 8 characters long').isStrongPassword().withMessage('Weak password, try adding numbers and special characters'),
    check('role').optional().isIn(['admin', 'user']).withMessage('Role must be either admin or user'),
    check('user_phone').optional().isMobilePhone().withMessage('Invalid phone number format'),
    check('joined_on').optional().isISO8601().withMessage('Invalid date format, must be YYYY-MM-DD'),
];

const updateUserValidation = [
    check('username').optional().isString().withMessage('Username must be a string'),
    check('email').optional().isEmail().withMessage('Invalid Email Format'),
    check('password').optional().isLength({ min: 8 }).withMessage('Password must be at least 8 characters long').isStrongPassword().withMessage('Weak password, try adding numbers and special characters'),
    check('role').optional().isIn(['admin', 'user']).withMessage('Role must be either admin or user'),
    check('user_phone').optional().isMobilePhone().withMessage('Invalid phone number format'),
    check('joined_on').optional().isISO8601().withMessage('Invalid date format, must be YYYY-MM-DD'),
];

module.exports = {
  insertUserValidation,
  updateUserValidation,
};

