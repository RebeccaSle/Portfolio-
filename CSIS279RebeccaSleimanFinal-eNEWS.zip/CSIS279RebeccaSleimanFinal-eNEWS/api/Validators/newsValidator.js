const { check } = require('express-validator');

const insertNewsValidation = [
  check('newsid').isInt().withMessage('News ID must be an integer'),
  check('content').notEmpty().withMessage('Content is required'),
  check('categoryid').isInt().withMessage('Category ID must be an integer'),
  check('authorid').isInt().withMessage('Author ID must be an integer'),
  check('image').optional().isString().withMessage('Image must be a string'),
  check('publish_at').optional().isISO8601().withMessage('Invalid publish date format, must be YYYY-MM-DD'),
  check('is_active').optional().isBoolean().withMessage('is_active must be a boolean'),
  check('created_at').optional().isISO8601().withMessage('Invalid created date format, must be YYYY-MM-DD'),
];

const updateNewsValidation = [
  check('content').optional().isString().withMessage('Content must be a string'),
  check('categoryid').optional().isInt().withMessage('Category ID must be an integer'),
  check('authorid').optional().isInt().withMessage('Author ID must be an integer'),
  check('image').optional().isString().withMessage('Image must be a string'),
  check('publish_at').optional().isISO8601().withMessage('Invalid publish date format, must be YYYY-MM-DD'),
  check('is_active').optional().isBoolean().withMessage('is_active must be a boolean'),
  check('click_count').optional().isInt({ min: 0 }).withMessage('click_count must be a non-negative integer'), 
];

module.exports = {
  insertNewsValidation,
  updateNewsValidation,
};