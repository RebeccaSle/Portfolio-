const { check } = require('express-validator');

const insertAuthorValidation = [
  check('authorid').isInt().withMessage('Author ID must be an integer'),
  check('authorname').notEmpty().withMessage('Author name is required').isString().withMessage('Author name must be a string'),
];

const updateAuthorValidation = [
  check('authorname').notEmpty().withMessage('Author name is required').isString().withMessage('Author name must be a string'),
];

module.exports = {
  insertAuthorValidation,
  updateAuthorValidation,
};