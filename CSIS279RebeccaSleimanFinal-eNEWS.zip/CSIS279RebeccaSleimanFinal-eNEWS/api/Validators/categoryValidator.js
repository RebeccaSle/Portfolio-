const { check } = require('express-validator');

const insertCategoryValidation = [
  check('categoryid').isInt().withMessage('Category ID must be an integer'),
  check('categoryname').isString().withMessage('Category name must be a string'),
];

const updateCategoryValidation = [
  check('categoryname').isString().withMessage('Category name must be a string'),
];

module.exports = {
  insertCategoryValidation,
  updateCategoryValidation,
};