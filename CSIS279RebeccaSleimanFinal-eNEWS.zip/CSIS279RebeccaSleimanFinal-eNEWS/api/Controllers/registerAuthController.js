const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const User = require("../Models/User");
const { Op } = require("sequelize");
require("dotenv").config();

const saltRounds = 10; 

const registerAuthController = async (req, res) => {
  const { username, email, password, phone } = req.body;

  if (!username || !email || !password || !phone) {
    return res.status(400).json({ message: "All fields are required" });
  }

  try {
    const existingUser = await User.findOne({ 
      where: { 
        [Op.or]: [{ username: username }, { email: email }] 
      }
    });

    if (existingUser) {
      return res.status(409).json({ message: "Username or email already exists" });
    }

    const hashedPassword = await bcrypt.hash(password, saltRounds);

    const newUser = await User.create({
      username: username,
      email: email,
      password: hashedPassword,
      user_phone: phone,
      joined_on: new Date(),
    });

    console.log("User created successfully:", newUser);

    const token = jwt.sign(
      { userid: newUser.id, username: newUser.username, role: "user" }, // Add default role if not specified
      process.env.JWT_SECRET,
      { expiresIn: "1h" }
    );

    console.log("Token generated for new user:", newUser.username);

    return res.status(201).json({
      message: "User registered successfully",
      token: token,
      user: {
        id: newUser.id,
        username: newUser.username,
        email: newUser.email,
        user_phone: newUser.user_phone,
        role:newUser.role,
      },
    });
  } catch (error) {
    console.error("Error during registration:", error);
    return res.status(500).json({ message: "Server error during registration" });
  }
};

module.exports = registerAuthController;
