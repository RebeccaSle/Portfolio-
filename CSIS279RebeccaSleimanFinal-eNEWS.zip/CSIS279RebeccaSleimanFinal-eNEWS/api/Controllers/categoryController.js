const categoryService = require('../Services/categoryService');

const categoryController = {

    /**
     * Get all categories
     * @returns {Promise<Array>} - An array of categories
     */
    getAllCategoriesController: async (req, res) => {
        try {
            const categories = await categoryService.getAllCategories();
            return res.status(200).json(categories);
        } catch (err) {
            console.error('Error retrieving categories:', err);
            return res.status(500).json({ message: 'Failed to retrieve categories' });
        }
    },

    /**
     * Get a category by ID
     * @param {number} id - The ID of the category to retrieve
     * @returns {Promise<Object>} - The category object
     */
    getCategoryByIdController: async (req, res) => {
        const { id } = req.params;
        try {
            const category = await categoryService.getCategoryById(id);

            if (!category) {
                return res.status(404).json({ message: `Category not found with ID: ${id}` });
            }

            return res.status(200).json(category);
        } catch (err) {
            console.error('Error retrieving category:', err);
            return res.status(500).json({ message: 'Failed to retrieve category' });
        }
    },

    /**
     * Create a new category
     * @param {Object} req - The request object containing category data
     * @param {Object} res - The response object
     * @returns {Promise<Object>} - The created category object
     */
    createCategoryController: async (req, res) => {
        const { categoryname } = req.body;
        if (!categoryname) {
            return res.status(400).json({ message: "Category name is required." });
        }
        try {
            const newCategory = await categoryService.createCategory(categoryname);
            return res.status(201).json(newCategory);
        } catch (err) {
            console.error('Error creating category:', err);
            return res.status(500).json({ message: 'Failed to create category' });
        }
    },

    /**
     * Delete a category by ID
     * @param {Object} req - The request object containing the category ID
     * @param {Object} res - The response object
     * @returns {Promise<void>}
     */
    deleteCategoryController: async (req, res) => {
        const { id } = req.params;
        if (!id) {
            return res.status(400).json({ message: "Category ID is required." });
        }

        try {
            const result = await categoryService.deleteCategory(id);
            if (result === 0) {
                return res.status(404).json({ message: "Category not found. No category deleted." });
            }

            res.status(200).json({ message: "Category deleted successfully." });

        } catch (error) {
            console.error("Error deleting category:", error.message);
            res.status(500).json({ message: "Internal server error occurred.", error: error?.message });
        }
    },

    /**
     * Update a category by ID
     * @param {Object} req - The request object containing the category ID and updated data
     * @param {Object} res - The response object
     * @returns {Promise<void>}
     */
    updateCategoryController: async (req, res) => {
        const categoryid = req.params.id;
        const { categoryname } = req.body;
        if (!categoryid) {
            return res.status(400).json({ message: "Category ID is required." });
        }
        if (!categoryname) {
            return res.status(400).json({ message: "Category name is required." });
        }

        try {
            const result = await categoryService.updateCategory(categoryid, categoryname);
            
            if (!result) {
                return res.status(404).json({ message: "Category not found." });
            }

            res.status(200).json({ message: "Category updated successfully", category: result });
        } catch (error) {
            console.error("Error updating category:", error.message);
            res.status(500).json({ message: "Internal server error.", error: error?.message });
        }
    }
};

module.exports = categoryController;
