const authorService = require('../Services/authorService');

const authorController = {

    /**
     * Get all authors
     * @returns {Promise<Array>} - An array of authors
     */
    getAllAuthorsController: async (req, res) => {
        try {
            const authors = await authorService.getAllAuthors();
            return res.status(200).json(authors);
        } catch (err) {
            console.error('Error retrieving authors:', err);
            return res.status(500).json({ message: 'Failed to retrieve authors' });
        }
    },

    /**
     * Get an author by ID
     * @param {number} id - The ID of the author to retrieve
     * @returns {Promise<Object>} - The author object
     */
    getAuthorByIdController: async (req, res) => {
        const { authorid } = req.params;
        try {
            const author = await authorService.getAuthorById(authorid);

            if (!author) {
                return res.status(404).json({ message: `Author not found with ID: ${authorid}` });
            }

            return res.status(200).json(author);
        } catch (err) {
            console.error('Error retrieving author:', err);
            return res.status(500).json({ message: 'Failed to retrieve author' });
        }
    },

    /**
     * Create a new author
     * @param {Object} req - The request object containing author data
     * @param {Object} res - The response object
     * @returns {Promise<Object>} - The created author object
     */
    createAuthorController: async (req, res) => {
        const { authorname } = req.body;
        try {
            const newAuthor = await authorService.createAuthor(authorname);
            return res.status(201).json(newAuthor);
        } catch (err) {
            console.error('Error creating author:', err);
            return res.status(500).json({ message: 'Failed to create author' });
        }
    },

    /**
     * Delete an author by ID
     * @param {Object} req - The request object containing the author ID
     * @param {Object} res - The response object
     * @returns {Promise<void>}
     */
    deleteAuthorController: async (req, res) => {
        const { id } = req.params;
        if (!id) {
            return res.status(400).json({ message: "Author ID is required." });
        }

        try {
            const result = await authorService.deleteAuthor(id);
            if (result === 0) {
                return res.status(404).json({ message: "Author not found. No author deleted." });
            }

            res.status(200).json({ message: "Author deleted successfully." });

        } catch (error) {
            console.error("Error deleting author:", error.message);
            res.status(500).json({ message: "Internal server error occurred.", error: error?.message });
        }
    },

    /**
     * Update an author by ID
     * @param {Object} req - The request object containing the author ID and updated data
     * @param {Object} res - The response object
     * @returns {Promise<void>}
     */
    updateAuthorController: async (req, res) => {
        const authorid = req.params.id;
        const { authorname } = req.body;
        if (!authorid) {
            return res.status(400).json({ message: "Author ID is required." });
        }

        try {
            const result = await authorService.updateAuthor(authorid, authorname);

            if (!result) {
                return res.status(404).json({ message: "Author not found." });
            }

            res.status(200).json({ message: "Author updated successfully", author: result });
        } catch (error) {
            console.error("Error updating author:", error.message);
            res.status(500).json({ message: "Internal server error.", error: error?.message });
        }
    }
};

module.exports = authorController;
