const newsService = require('../Services/newsService');

const newsController = {

    /**
     * Retrieve all news articles.
     * @returns {Promise<Object>} - A response object containing the success status, count, and list of news articles
     */
    getAllNewsController: async (req, res) => {
        try {
            const news = await newsService.getAllNews();
            res.status(200).json({ success: true, count: news.length, news });
        } catch (error) {
            console.error("Error retrieving news:", error.message);
            res.status(500).json({ success: false, error: error?.message || "Failed to retrieve news" });
        }
    },

    /**
     * Retrieve a specific news article by its ID.
     * @param {string} newsid - The ID of the news article to retrieve.
     * @returns {Promise<Object>} - A response object containing the success status and the requested news article
     */
    getNewsByIdController: async (req, res) => {
        const { newsid } = req.params;
        try {
            const news = await newsService.getNewsById(newsid);
            if (!news) {
                return res.status(404).json({ success: false, error: `News not found for ID: ${newsid}` });
            }
            res.status(200).json({ success: true, news });
        } catch (error) {
            console.error(`Error retrieving news with ID ${newsid}:`, error);
            res.status(500).json({ success: false, error: "Failed to retrieve news. Server error" });
        }
    },

    /**
     * Update a specific news article by its ID.
     * @param {string} newsid - The ID of the news article to update.
     * @param {string} title - The new title of the news article.
     * @param {string} content - The new content of the news article.
     * @param {number} categoryid - The new category ID for the news article.
     * @param {number} authorid - The ID of the author of the news article.
     * @param {string} image - The path to the image for the news article 
     * @param {Date} publish_at - The publish date for the news article.
     * @param {boolean} is_active - The active status of the news article.
     * @returns {Promise<Object>} - A response object with success status and updated news article.
     */
    updateNewsController: async (req, res) => {
        const newsid = req.params.newsid;
        const { title, content, categoryid, authorid, publish_at, is_active } = req.body;
        const image = req.file ? req.file.path : null;

        if (!newsid) {
            return res.status(400).json({ success: false, message: "News ID is required to update news details." });
        }

        try {
            const result = await newsService.updateNews(newsid, title, content, categoryid, authorid, image, publish_at, is_active);

            if (!result) {
                return res.status(404).json({ success: false, message: "News article not found." });
            }
            res.status(200).json({ success: true, message: "News updated successfully", news: result });
        } catch (error) {
            console.error("Error updating news:", error.message);
            res.status(500).json({ success: false, message: "Internal server error while updating news.", error: error.message });
        }
    },

    /**
     * Delete a specific news article by its ID.
     * @param {string} newsid - The ID of the news article to delete.
     * @returns {Promise<void>} - A response indicating success or failure of the delete operation.
     */
    deleteNewsController: async (req, res) => {
        const { newsid } = req.params;

        if (!newsid) {
            return res.status(400).json({ success: false, message: "News ID is required to delete a news." });
        }

        try {
            const result = await newsService.deleteNews(newsid);

            if (result === 0) {
                return res.status(404).json({ success: false, message: "News not found. No news deleted." });
            }

            res.status(200).json({ success: true, message: "News deleted successfully." });
        } catch (error) {
            console.error("Error deleting news:", error.message);
            res.status(500).json({ success: false, message: "Internal server error occurred while attempting to delete news.", error: error?.message });
        }
    },

    /**
     * Create a new news article.
     * @param {string} title - The title of the new news article.
     * @param {string} content - The content of the new news article.
     * @param {number} categoryid - The category ID for the new news article.
     * @param {number} authorid - The ID of the author of the new news article.
     * @param {string} image - The image associated with the new news article and is optional 
     * @param {Date} publish_at - The publish date for the new news article.
     * @param {boolean} is_active - Whether the new news article is active.
     * @returns {Promise<Object>} - A response with the success status and created news article.
     */
    createNewsController: async (req, res) => {
        const { content, title, categoryid, authorid, publish_at, is_active } = req.body;
        const image = req.file ? req.file.path : null;

        if (!title || !content || !categoryid || !authorid) {
            return res.status(400).json({ success: false, message: "Content, title, category ID, and author ID are required." });
        }

        try {
            const newNews = await newsService.createNews({ content, title, categoryid, authorid, image, publish_at, is_active });
            res.status(201).json({ success: true, message: "News created successfully.", news: newNews });
        } catch (error) {
            console.error("Error creating news:", error.message);
            res.status(500).json({ success: false, message: "Internal server error.", error: error.message });
        }
    },

    /**
     * Retrieve news articles by category ID.
     * @param {string} categoryid - The category ID to filter the news articles.
     * @returns {Promise<Object>} - A response containing the success status and a list of news articles by category.
     */
    getNewsByCategoryId: async (req, res) => {
        const { categoryid } = req.params;

        if (!categoryid) {
            return res.status(400).json({ success: false, message: "Category ID is required." });
        }

        try {
            const news = await newsService.getNewsByCategoryId(categoryid);

            if (!news || news.length === 0) {
                return res.status(404).json({ success: false, message: "No news articles found for this category." });
            }

            res.status(200).json({ success: true, news });
        } catch (error) {
            console.error("Error retrieving news by category:", error.message);
            res.status(500).json({ success: false, message: "Failed to retrieve news by category.", error: error.message });
        }
    },

    /**
     * Retrieve news articles by author ID.
     * @param {string} authorid - The author ID to filter the news articles.
     * @returns {Promise<Object>} - A response containing the success status and a list of news articles by author.
     */
    getNewsByAuthorId: async (req, res) => {
        const { authorid } = req.params;

        if (!authorid) {
            return res.status(400).json({ success: false, message: "Author ID is required." });
        }

        try {
            const news = await newsService.getNewsByAuthorId(authorid);

            if (!news || news.length === 0) {
                return res.status(404).json({ success: false, message: "No news articles found for this author." });
            }

            res.status(200).json({ success: true, news });
        } catch (error) {
            console.error("Error retrieving news by author:", error.message);
            res.status(500).json({ success: false, message: "Failed to retrieve news by author.", error: error.message });
        }
    },

    /**
     * Update the active status of a specific news article.
     * @param {string} newsid - The ID of the news article to update.
     * @param {boolean} is_active - The new active status of the news article.
     * @returns {Promise<Object>} - A response indicating the result of the update operation.
     */
    updateActivity: async (req, res) => {
        const { newsid } = req.params;
        const { is_active } = req.body;

        try {
            const message = await newsService.updateActivity(newsid, is_active);
            return res.status(200).json({ success: true, message });
        } catch (error) {
            console.error("Error updating activity:", error.message);
            return res.status(500).json({ success: false, message: "Internal server error.", error: error.message });
        }
    },

    /**
     * Retrieve news articles by their active status.
     * @param {boolean} is_active - The active status filter (0 or 1).
     * @returns {Promise<Object>} - A response containing the success status and filtered news articles.
     */
    getNewsByActivityController: async (req, res) => {
        const { is_active } = req.params;

        if (is_active !== "0" && is_active !== "1") {
            return res.status(400).json({ success: false, message: "Invalid is_active value. Must be 0 or 1." });
        }

        try {
            const news = await newsService.getNewsByActivity(Number(is_active));
            res.status(200).json({ success: true, count: news.length, news });
        } catch (error) {
            console.error("Error retrieving news by activity status:", error.message);
            res.status(500).json({ success: false, error: "Failed to retrieve news by activity status.", message: error.message });
        }
    },

    /**
     * Retrieve published news articles.
     * @returns {Promise<Object>} - A response containing the success status and list of published news articles.
     */
    getPublishedNews: async (req, res) => {
        try {
            const publishedNews = await newsService.getPublishedNews();
            return res.status(200).json({ publishedNews });
        } catch (error) {
            console.error('Error in getPublishedNews controller:', error);
            return res.status(500).json({ error: error.message });
        }
    },

    /**
     * Retrieve upcoming news articles.
     * @returns {Promise<Object>} - A response containing the success status and list of upcoming news articles.
     */
    getUpcomingNews: async (req, res) => {
        try {
            const upcomingNews = await newsService.getUpcomingNews();
            return res.status(200).json({ upcomingNews });
        } catch (error) {
            console.error('Error in getUpcomingNews controller:', error);
            return res.status(500).json({ error: error.message });
        }
    }
};

module.exports = newsController;
