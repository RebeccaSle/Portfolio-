const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const User = require("../Models/User");

require("dotenv").config();

const userAuthController = async (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ message: "missing username or password" });
  }

  try {
    const user = await User.findOne({ where: { username: username } });

    if (!user) {
      console.log("User not found for username:", username); 
      return res.status(401).json({ message: "invalid username or password" });
    }

    console.log("User found:", { userid: user.userid, username: user.username, role: user.role });

    const validPass = await bcrypt.compare(password, user.password);
    console.log("Password comparison result:", validPass);

    if (!validPass) {
      console.log("Invalid password for username:", username); 
      return res.status(401).json({ message: "invalid username or password" });
    }

    const token = jwt.sign(
      { userid: user.userid, username: user.username, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: "1h" }
    );
    console.log("Token generated for user:", username); 

    return res.status(200).json({ token });
  } catch (error) {
    console.error("Error authenticating user", error);
    return res.status(500).json({ message: "server error" });
  }
};

module.exports = userAuthController;
