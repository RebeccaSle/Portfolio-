const userService = require('../Services/userService'); 
require("dotenv").config();

const userController = {
    getUserByIdController: async (req, res) => {
        const { userid } = req.params; 
        try {
            const user = await userService.getUserById(userid);
            if (!user) {
                return res.status(404).json({ error: "User not found" });
            }
            res.status(200).json(user);
        } catch (error) {
            console.error("Error retrieving user:", error); 
            res.status(500).json({ error: "Failed to retrieve user" });
        }
    },

    getAllUsersController: async (req, res) => {
        try {
            const users = await userService.getAllUsers();
           
        if (!users || users.length === 0) {
            return res.status(404).json({ message: 'No users found' });
        }

        res.status(200).json({ users });

        } catch (error) {
            console.error("Error retrieving users:", error);
            res.status(500).json({ error: error?.message || "Failed to retrieve users" });
        }
    },

    createUserController: async (req, res) => {
        const { username, email, password, user_phone } = req.body;

        if (!username || !email || !password || !user_phone) {
            return res.status(400).json({ message: "Missing required fields" });
        }
    
        try {
            const existingUser = await userService.getUserByEmail(email);
            if (existingUser) {
                return res.status(400).json({ message: "User already exists with this email" });
            }
    
            const newUser = await userService.createUser(username, email, password, user_phone);
    
            if (!newUser) {
                return res.status(500).json({ message: "Failed to create new user" });
            }
    
            res.status(201).json({
                message: "New user created successfully",
                user: {
                    id: newUser.userid,
                    username: newUser.username,
                    email: newUser.email,
                    user_phone: newUser.user_phone,
                    joined_on: newUser.joined_on
                }
            });
    
        } catch (error) {
            console.error("Error during user creation:", error); 
            res.status(500).json({ message: error.message || 'An unexpected error occurred during user creation' });
        }
    },

    updateUserController: async (req,res) =>{
        const {userid} = req.params;
        const { username, email, oldPassword, newPassword, user_phone } = req.body;
    
        if (!userid) {
            return res.status(400).json({ message: "User ID is required to update user details." });
        }
    
        if (newPassword && !oldPassword) {
            return res.status(400).json({ message: "Old password is required to update to a new password." });
        }
    
        try {
            const result = await userService.updateUser(userid, {
                username,
                email,
                oldPassword,
                newPassword,
                user_phone
            });
    
            if (result.error === "Old password is incorrect") {
                return res.status(400).json({ message: "The provided old password is incorrect." });
            } else if (result.error === "User not found") {
                return res.status(404).json({ message: "User not found." });
            }
    
            res.status(200).json({ message: "User updated successfully", user: result });
        } catch (error) {
            console.error("Error updating user:", error.message);
            res.status(500).json({ message: "Internal server error while updating user.", error: error?.message });
        }
    },

    deleteUserController: async (req, res) => {
        const { userid } = req.params; 
        

        if (!userid) {
            return res.status(400).json({ message: "User ID is required to delete a user." });
        }

        try {
        const result = await userService.deleteUser(userid);

        if (result === 0) {
            return res.status(404).json({ message: "User not found. No user deleted." });
        }

        res.status(200).json({ message: "User deleted successfully." });

        } catch (error) {
        console.error("Error deleting user:", error.message);
        res.status(500).json({ message: "Internal server error occurred while attempting to delete the user.", error: error?.message });
    }
    },

    getUsersByRoleController: async (req, res) => {
        const { role } = req.params; 

        try {
            const users = await userService.getAllUsers(); 
            const filteredUsers = users.filter(user => user.role === role); 

            res.status(200).json({ users: filteredUsers });
        } catch (error) {
            console.error('Error retrieving users by role:', error);
            res.status(500).json({ error: error.message });
        }
    },

    updatePasswordController: async (req, res) => {
        const userid = req.params.userid; // Get the user ID from the URL parameter
        const { newPassword } = req.body; // Get the new password from the request body

        // Ensure the necessary field is provided
        if (!newPassword) {
            return res.status(400).json({ message: "New password is required." });
        }

        try {
            // Call the updatePasswordService to update the user's password
            const updatedUser = await userService.updatePasswordService(userid, newPassword);

            // If the user is not found, handle it gracefully
            if (updatedUser.error === "User not found") {
                return res.status(404).json({ message: "User not found." });
            }

            // Return a success message with updated user details (excluding password)
            res.status(200).json({
                message: "Password updated successfully",
                user: updatedUser
            });
        } catch (error) {
            console.error('Error in updatePasswordController:', error);
            res.status(500).json({ message: 'Failed to update password', error: error.message });
        }
    }
 
    };

module.exports = userController;
