const express = require('express');
const router = express.Router();
const newsController = require('../Controllers/newsController');
const newsValidation = require ('../Validators/newsValidator');

router.put('/:newsid', newsController.updateActivity); //tested

router.get('/activity/:is_active', newsController.getNewsByActivityController); //tested
router.get('/', newsController.getAllNewsController); //tested
router.get('/:newsid', newsController.getNewsByIdController); //tested
router.get('/category/:categoryid', newsController.getNewsByCategoryId); //tested
//router.get('/news/published', newsController.getPublishedNews); 
//router.get('/news/upcoming', newsController.getUpcomingNews); 

router.post('/', newsController.createNewsController, newsValidation.insertNewsValidation); //tested

router.delete('/:newsid', newsController.deleteNewsController); //tested

router.put('/:newsid', newsController.updateNewsController); //tested


/**
 * get news by author id
 */

module.exports = router;
