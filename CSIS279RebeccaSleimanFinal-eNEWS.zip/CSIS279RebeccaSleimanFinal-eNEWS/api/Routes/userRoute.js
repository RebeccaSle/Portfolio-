const express = require('express');
const router = express.Router();
const userController = require('../Controllers/userController');
const userValidator = require('../Validators/userValidator');
const userAuthController = require("../Controllers/userAuthController");
const authToken = require ("../Middleware/AuthToken");
const registerAuthController = require ("../Controllers/registerAuthController");
/***
 * I should add 
 * authentication 
 * where needed
 */

//Post Routes
router.post('/user', userController.createUserController, userValidator.insertUserValidation); //tested
router.post('/auth/register', registerAuthController); //tested REGISTER
router.post("/auth/login", userAuthController); //tested LOGIN
//Get Routes
router.get('/all', userController.getAllUsersController); //tested
router.get('/:userid', authToken, userController.getUserByIdController); //tested
router.get('/role', authToken, userController.getUsersByRoleController);

//Put Routes
router.put('/:userid', authToken, userController.updateUserController, userValidator.updateUserValidation); //TESTED
router.put('/:userid/password', authToken, userController.updatePasswordController); //tested

//Delete Route
router.delete('/:userid', authToken, userController.deleteUserController); //tested

//get user by role (already has a controller and service)
//refresh token(no controller but this one is optinal)

module.exports = router;
