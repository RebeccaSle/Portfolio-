const express = require('express');
const categoryController = require('../Controllers/categoryController'); 
const router = express.Router();

router.get('/', categoryController.getAllCategoriesController); //tested
router.get('/:id', categoryController.getCategoryByIdController); //tested

router.post('/', categoryController.createCategoryController); //tested

router.delete('/:id', categoryController.deleteCategoryController); //tested

router.put('/:id', categoryController.updateCategoryController); //tested

module.exports = router;
