const express = require('express');
const router = express.Router();
const authorController = require('../Controllers/authorController');

// Route to get all authors
router.get('/', authorController.getAllAuthorsController); //tested

// Route to get an author by ID
router.get('/:authorid', authorController.getAuthorByIdController); //tested

// Route to create a new author
router.post('/authors', authorController.createAuthorController); //tested

// Route to update an author by ID
router.put('/authors/:id', authorController.updateAuthorController); //tested

// Route to delete an author by ID
router.delete('/authors/:id', authorController.deleteAuthorController); //tested

module.exports = router;
