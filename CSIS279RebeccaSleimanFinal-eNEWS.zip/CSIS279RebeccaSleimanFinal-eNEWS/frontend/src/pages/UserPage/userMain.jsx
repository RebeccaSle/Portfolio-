import React from "react";
import NewsDashboard from "../../components/NewsDashboard/NewsDashboard";
import requireAuth from "../../hoc/requireAuth";
import UserVideoStream from "../../components/videoStream/UserVideoStream";

const UserMain = () => {
    return (
        <div>
            <NewsDashboard />
            <UserVideoStream />
        </div>
    );
};

export default requireAuth(UserMain, 'user'); 
