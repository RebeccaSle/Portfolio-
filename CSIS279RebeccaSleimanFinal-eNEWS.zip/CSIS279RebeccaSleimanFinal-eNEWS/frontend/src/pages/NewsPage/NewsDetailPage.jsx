import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import newsService from '../../services/newsService';
import './NewsDetailPage.css';

const NewsDetail = () => {
    const { id } = useParams(); 
    const [news, setNews] = useState(null);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchNewsDetail = async () => {
            try {
                const response = await newsService.getNewsById(id);
                setNews(response.news);
            } catch (err) {
                setError('Failed to fetch news details.');
            }
        };
        fetchNewsDetail();
    }, [id]);

    if (error) {
        return (
            <div className="container text-center mt-5">
                <div className="alert alert-danger">{error}</div>
            </div>
        );
    }

    if (!news) {
        return (
            <div className="container text-center mt-5">
                <div className="spinner-border text-primary" role="status">
                    <span className="visually-hidden">Loading...</span>
                </div>
            </div>
        );
    }

    return (
        <div className="container mt-5">
            <div className="row">
                <div className="col-lg-4 col-md-4 col-sm-12">
                    <div className="sidebar">
                        <div className="sidebar-item">
                            <strong>Author ID:</strong> {news.authorid || 'N/A'}
                        </div>
                        <div className="sidebar-item">
                            <strong>Category ID:</strong> {news.categoryid || 'N/A'}
                        </div>
                        <div className="sidebar-item">
                            <strong>Published on:</strong> {news.publish_at ? new Date(news.publish_at).toLocaleDateString() : 'N/A'}
                        </div>
                      
                        
                    </div>
                </div>

                <div className="col-lg-8 col-md-8 col-sm-12">
                    <div className="news-detail">
                        <h1 className="news-title">{news.title || 'Untitled Article'}</h1>
                        <div className="news-content">
                            <img 
                                src={`/${news.image}`} 
                                alt="Article" 
                                className="img-fluid rounded shadow mb-4" 
                            />
                            <p className="lead">{news.content || 'No content available for this article.'}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default NewsDetail;
