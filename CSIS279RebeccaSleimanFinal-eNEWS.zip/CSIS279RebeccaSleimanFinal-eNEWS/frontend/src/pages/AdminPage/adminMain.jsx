import React from "react";
import NewsDashboard from "../../components/NewsDashboard/NewsDashboard";
import Button from '../../components/Button/Button'; 
import AdminVideoStream from "../../components/videoStream/AdminVideoStream";  
import requireAuth from "../../hoc/requireAuth";

const AdminMain = () => {
    return (
        <div>
            <Button text="View inactive news" url="/inactive" />
            <NewsDashboard />
            <Button text="Add News Here" url="/create-news" />
            
            <AdminVideoStream />
        </div>
    );
};

export default requireAuth(AdminMain, 'admin');
