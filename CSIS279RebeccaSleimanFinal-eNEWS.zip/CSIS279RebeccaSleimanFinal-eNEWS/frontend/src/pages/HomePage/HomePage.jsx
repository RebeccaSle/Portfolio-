import React from 'react';
import '../HomePage/HomePage.css'; 
import Button from '../../components/Button/Button';

const HomePage = () => {
    const pictures = [
        { src :'http://localhost:3001/uploads/images/fashion.jpg', caption: 'Breaking News Coverage' },
        { src :'http://localhost:3001/uploads/images/lebanon.jpeg', caption: 'Breaking News Coverage' },
        { src :'http://localhost:3001/uploads/images/polution.jpeg', caption: 'Breaking News Coverage' },
        { src :'http://localhost:3001/uploads/images/programming.jpeg', caption: 'Breaking News Coverage' },
        { src :'http://localhost:3001/uploads/images/sports.jpeg', caption: 'Breaking News Coverage' },
        { src :'http://localhost:3001/uploads/images/war.jpeg', caption: 'Breaking News Coverage' },
    
    ];

    return (
        <div className="homepage">
           
            <div className="intro-container">
                <h1 className="intro-title">eNEWS</h1>
                <h2 className="intro-subtitle">Get the latest updates on global news and trends, all in one place.</h2>
            </div>

            <section className="content-section">
                <div className="image-container">
                    {pictures.slice(0, 3).map((picture, index) => (
                        <img 
                            key={index} 
                            src={picture.src} 
                            alt={picture.caption} 
                            className="content-image" 
                        />
                    ))}
                </div>
                <div className="text-container">
                    <h2>Why Choose eNews?</h2>
                    <p>
                        eNews is dedicated to bringing you the latest updates from around the world. Whether it’s breaking news, 
                        detailed analysis, or trending stories, we’ve got you covered. Our commitment to quality journalism ensures 
                        that you stay informed and empowered.
                    </p>
                </div>
            </section>

            <div className="intro-container">
                <h1 className="intro-title">New Here?</h1>
                <h2 className="intro-subtitle">Hurry and create an account to stay up to date!.</h2>
                <Button text="Register Now" url="/register" />
            </div>


            <section className="content-section reverse">
                <div className="image-container">
                    {pictures.slice(3).map((picture, index) => (
                        <img 
                            key={index} 
                            src={picture.src} 
                            alt={picture.caption} 
                            className="content-image" 
                        />
                    ))}
                </div>
                <div className="text-container">
                    <h2>Explore More with eNews</h2>
                    <p>
                        Dive into stories that matter. From technology breakthroughs to global entertainment, 
                        our platform brings you a diverse range of topics that cater to your interests. Stay curious, stay informed.
                    </p>
                </div>
            </section>

            <div className="intro-container">
                <h1 className="intro-title">Been Here Before ?</h1>
                <h2 className="intro-subtitle">Log in to your account </h2>
                <Button text="Login Now" url="/login" />
            </div>
           
        </div>
    );
};

export default HomePage;
