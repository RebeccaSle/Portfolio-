import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import newsService from "../../services/newsService";
import ToggleActivity from "../../components/ToggleActivity";
import requireAuth from "../../hoc/requireAuth";
import "../../components/NewsDashboard/NewsDashboard.css";

const InactivePage = () => {
    const [news, setNews] = useState([]);
    const [error, setError] = useState(null);
    const [currentPage, setCurrentPage] = useState(1);
    const articlesPerPage = 8;
    const navigate = useNavigate();

    useEffect(() => {
        const fetchInactiveNews = async () => {
            try {
                const response = await newsService.getNewsByActivity(0); 
                setNews(response.news); 
            } catch (err) {
                setError("Failed to fetch inactive news.");
            }
        };

        fetchInactiveNews();
    }, []);

    const totalPages = Math.ceil(news.length / articlesPerPage);

    const handlePrevPage = () => {
        setCurrentPage((prev) => Math.max(prev - 1, 1));
    };

    const handleNextPage = () => {
        setCurrentPage((prev) => Math.min(prev + 1, totalPages));
    };

    const indexOfLastArticle = currentPage * articlesPerPage;
    const indexOfFirstArticle = indexOfLastArticle - articlesPerPage;
    const currentNews = news.slice(indexOfFirstArticle, indexOfLastArticle);

    const handleClickNews = (id) => {
        navigate(`/news/${id}`); 
    };

    const handleStatusChange = (newsid, newStatus) => {
        setNews((prevNews) =>
            prevNews.map((item) =>
                item.newsid === newsid ? { ...item, is_active: newStatus } : item
            )
        );
    };

    if (error) {
        return <p>{error}</p>;
    }

    return (
        <div className="news-dashboard">
            <h2>Inactive News</h2>
            {currentNews.length > 0 ? (
                <ul className="news-list">
                    {currentNews.map((item) => (
                        <li key={item.newsid} className="news-item">
                            {item.Image && (
                                <img
                                    src={`http://localhost:3001${item.Image}`}
                                    alt={item.title || "News Image"}
                                    className="news-image"
                                    onClick={() => handleClickNews(item.newsid)}
                                />
                            )}
                            <h3 onClick={() => handleClickNews(item.newsid)}>
                                {item.title || "Untitled Article"}
                            </h3>
                            <ToggleActivity
                                newsid={item.newsid}
                                initialIsActive={item.is_active}
                                onStatusChange={(newStatus) =>
                                    handleStatusChange(item.newsid, newStatus)
                                }
                            />
                        </li>
                    ))}
                </ul>
            ) : (
                <p>No inactive news available.</p>
            )}
            <div className="pagination">
                <button
                    onClick={handlePrevPage}
                    disabled={currentPage === 1}
                    className="pagination-button"
                >
                    Previous
                </button>
                <span>
                    Page {currentPage} of {totalPages}
                </span>
                <button
                    onClick={handleNextPage}
                    disabled={currentPage === totalPages}
                    className="pagination-button"
                >
                    Next
                </button>
            </div>
        </div>
    );
};

export default requireAuth(InactivePage, "admin");
