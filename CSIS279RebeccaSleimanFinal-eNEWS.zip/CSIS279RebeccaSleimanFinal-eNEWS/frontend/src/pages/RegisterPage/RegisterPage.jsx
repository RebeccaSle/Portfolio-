import React, { useState } from 'react';
import { registerUser } from '../../services/userService';
import { useNavigate } from 'react-router-dom';
import useForm from '../../hooks/useForm'; 
import 'bootstrap/dist/css/bootstrap.min.css'; 
import '../RegisterPage/RegisterPage.css';

const RegisterPage = () => {
  const [values, handleChange, resetForm] = useForm({ 
    username: '', 
    email: '', 
    password: '', 
    phone: '' 
  });
  const [message, setMessage] = useState('');
  
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage(''); 

    try {
      const data = await registerUser(values.username, values.email, values.password, values.phone);
      
      if (data) {
        setMessage('Registration successful!');
        resetForm(); 
        navigate('/userMain'); 
      }
    } catch (error) {
      setMessage('Registration failed. Please try again.');
    }
  };

  return (
    <div className="container d-flex justify-content-center align-items-center" style={{ height: '100vh' }}>
         

      <div className="card p-4" style={{ width: '400px' }}>
        <h2 className="text-center mb-4">Register</h2>
        
        {message && <div className={`alert ${message.includes('successful') ? 'alert-success' : 'alert-danger'}`}>{message}</div>}
        
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label htmlFor="username" className="form-label">Username</label>
            <input
              type="text"
              className="form-control"
              id="username"
              name="username" 
              value={values.username}
              onChange={handleChange}
              required
            />
          </div>
          <div className="mb-3">
            <label htmlFor="email" className="form-label">Email</label>
            <input
              type="email"
              className="form-control"
              id="email"
              name="email" 
              value={values.email}
              onChange={handleChange}
              required
            />
          </div>
          <div className="mb-3">
            <label htmlFor="password" className="form-label">Password</label>
            <input
              type="password"
              className="form-control"
              id="password"
              name="password" 
              value={values.password}
              onChange={handleChange}
              required
            />
          </div>
          <div className="mb-3">
            <label htmlFor="phone" className="form-label">Phone</label>
            <input
              type="text"
              className="form-control"
              id="phone"
              name="phone" 
              value={values.phone}
              onChange={handleChange}
              required
            />
          </div>
          <button type="submit" className="btn btn-primary w-100">Register</button>
        </form>
        
        <div className="mt-3 text-center">
          <p>Already have an account? <a href="/login">Login here</a></p>
        </div>
      </div>
    </div>
  );
};

export default RegisterPage;
