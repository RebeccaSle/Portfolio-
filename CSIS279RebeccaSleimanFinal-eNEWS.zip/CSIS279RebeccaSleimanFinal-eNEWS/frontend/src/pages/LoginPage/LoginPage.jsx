import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { loginUser } from '../../services/userService';
import useForm from '../../hooks/useForm';
import { decodeToken } from '../../utils/Utils'; 

const LoginPage = () => {
  const [values, handleChange, resetForm] = useForm({ username: '', password: '' });
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setError(''); 

    try {
      const response = await loginUser(values.username, values.password);

      if (response.token) {
        const decoded = decodeToken();

        console.log(decoded?.role); 

        if (decoded?.role === 'admin') {
          navigate('/adminMain');
        } else if (decoded?.role === 'user') {
          navigate('/userMain');
        }

        resetForm();
      }
    } catch (err) {
      setError('Invalid username or password. Please try again.');
    }
  };

  return (
    <div
      className="container"
      style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}
    >
      <div className="card" style={{ width: '100%', maxWidth: '400px' }}>
        <h2 className="text-center" style={{ fontFamily: 'Poppins', fontWeight: 'bold' }}>Login</h2>

        {/* Display error message */}
        {error && <div className="alert alert-danger">{error}</div>}

        <form onSubmit={handleLogin}>
          <div className="mb-3">
            <label htmlFor="username" className="form-label" style={{ fontFamily: 'Poppins', fontWeight: 'normal' }}>
              Username
            </label>
            <input
              type="text"
              id="username"
              name="username" 
              className="form-control"
              value={values.username}
              onChange={handleChange}
              required
            />
          </div>

          <div className="mb-3">
            <label htmlFor="password" className="form-label" style={{ fontFamily: 'Poppins', fontWeight: 'normal' }}>
              Password
            </label>
            <input
              type="password"
              id="password"
              name="password" 
              className="form-control"
              value={values.password}
              onChange={handleChange}
              required
            />
          </div>

          <button type="submit" className="btn btn-primary w-100">Login</button>
        </form>

        <div className="mt-3 text-center">
          <p>Don't have an account? <a href="/register">Register here</a></p>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
