import React, { useEffect } from 'react';
import { Navigate } from 'react-router-dom';
import { getToken, decodeToken } from '../utils/Utils';
import useNotification from '../hooks/useNotification';

function requireAuth(Component, requiredRole) {
  return function AuthenticatedComponent(props) {
    const token = getToken();
    const isAuthenticated = token && decodeToken(token);
    const { message, showNotification } = useNotification();

    // Extract the role once after decoding the token
    const role = isAuthenticated ? decodeToken(token).role : null;

    useEffect(() => {
      if (!isAuthenticated) {
        showNotification('You need to log in to access this page.');
      } else if (requiredRole && role !== requiredRole) {
        showNotification('You are not an admin. Please log in using an admin account.');
      }
    }, [isAuthenticated, role, showNotification]);

    // If the user is not authenticated, redirect to login
    if (!isAuthenticated) {
      return <Navigate to="/login" replace />;
    }

    // If the role does not match, show the message without redirecting
    if (requiredRole && role !== requiredRole) {
      return (
        <div className="notification">
          <p>{message}</p>
        </div>
      );
    }

    // If the user is authenticated and has the correct role, return the component
    return <Component {...props} />;
  };
}

export default requireAuth;
