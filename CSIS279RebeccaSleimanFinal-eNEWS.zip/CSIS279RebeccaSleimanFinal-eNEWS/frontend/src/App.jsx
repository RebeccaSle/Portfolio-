import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'; 
import HomePage from './pages/HomePage/HomePage'; 
import RegisterPage from './pages/RegisterPage/RegisterPage'; 
import LoginPage from './pages/LoginPage/LoginPage';
import UserMain from './pages/UserPage/userMain';
import AdminMain from './pages/AdminPage/adminMain';
import Header from './components/Header/header';
import InactivePage from './pages/InactivePage/InactivePage';
import NewsDetailPage from './pages/NewsPage/NewsDetailPage'; 
import CreateNewsForm from './components/CreateNews/CreateNewsForm';
import Footer from './components/Footer/Footer';
import { SocketProvider } from './Context/Context'; 
import 'bootstrap/dist/css/bootstrap.min.css';

const App = () => {
  return (
    <SocketProvider> 
      <Router>
        <div>
          <Header />

          <Routes>
            <Route path="/" element={<HomePage />} /> 
            <Route path="/userMain" element={<UserMain />} />
            <Route path="/adminMain" element={<AdminMain />} />  
            <Route path="/inactive" element={<InactivePage />} />  
            <Route path="/register" element={<RegisterPage />} /> 
            <Route path="/login" element={<LoginPage />} />  
            <Route path="/news/:id" element={<NewsDetailPage />} /> 
            <Route path="/create-news" element={<CreateNewsForm />} /> 
          </Routes>
          <Footer />
        </div>
      </Router>
    </SocketProvider>
  );
};

export default App;
