import { jwtDecode } from 'jwt-decode'; // Correct named import

// Function to save the token to localStorage
const saveToken = (token) => {
  localStorage.setItem("token", JSON.stringify(token)); 
};

// Function to get the token from localStorage
const getToken = () => {
  const token = JSON.parse(localStorage.getItem("token"));
  return token;
};

// Function to get the token in Bearer format for Authorization headers
const getTokenBearer = () => {
  const token = getToken();
  return token ? `Bearer ${token}` : null; 
};

// Function to clear the token from localStorage
const clearToken = () => {
  localStorage.removeItem("token");
};

// Function to decode the token
const decodeToken = () => {
  const token = getToken();
  if (!token) return null;

  try {
    return jwtDecode(token);
  } catch (error) {
    console.error('Error decoding token:', error);
    return null; 
  }
};

export {
  saveToken,
  getToken,
  getTokenBearer,
  clearToken,
  decodeToken,
};
