import { useState } from 'react';

const useNotification = () => {
  const [message, setMessage] = useState('');

  const showNotification = (message) => {
    setMessage(message);
    setTimeout(() => {
      setMessage(''); 
    }, 5000);
  };

  return {
    message,
    showNotification,
  };
};

export default useNotification;
