import { useState, useRef } from "react"; 

// Custom hook to manage camera and microphone access
// provid startCamera thta start the camera and microphone
// stopCamera that stops the camera and microphone and release their jobs
// toggleMic to toggle the microphone's audio  on/off
// isCameraOn and isMicOn

const useMediaStream = () => {
  const [isCameraOn, setIsCameraOn] = useState(false);
  const [isMicOn, setIsMicOn] = useState(true);
  const videoRef = useRef(null);
  const mediaStreamRef = useRef(null);

  // Start camera and microphone
  const startCamera = async () => {
    if (!isCameraOn) {
      try {
        mediaStreamRef.current = await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: true,
        });
        if (videoRef.current) {
          videoRef.current.srcObject = mediaStreamRef.current;
        }
        setIsCameraOn(true);
      } catch (error) {
        console.error("Error accessing camera and microphone", error);
      }
    }
  };

  // Stop camera and microphone
  const stopCamera = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null; 
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null; 
    }
    setIsCameraOn(false);
  };

  // microphone 
  const toggleMic = () => {
    if (mediaStreamRef.current) {
      const audioTrack = mediaStreamRef.current.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !isMicOn;
        setIsMicOn(!isMicOn);
      }
    }
  };

  return { videoRef, isCameraOn, isMicOn, startCamera, stopCamera, toggleMic };
};

export default useMediaStream;
