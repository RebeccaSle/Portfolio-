import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import requireAuth from '../../hoc/requireAuth';
import useForm from '../../hooks/useForm'; 
import newsService from '../../services/newsService'; 
import categoryService from '../../services/categoryService'; 

/**
 * CreateNewsForm component that provides a form for creating news articles.
 * It includes fields for title, content, category, author , publish date, and image upload.
 * The form also handles fetching category data and submitting the form to create a news article.
 *
 * @component
 * @example
 * return (
 *   <CreateNewsForm />
 * )
 */
const CreateNewsForm = () => {
    const navigate = useNavigate();

    /**
     * useForm hook to manage form data.
     * @type {Object}
     * @property {string} title - The title of the news article.
     * @property {string} content - The content of the news article.
     * @property {string} categoryid - The selected category ID.
     * @property {string} authorid - The ID of the author of the news article.
     * @property {File|null} image - The uploaded image for the news article.
     * @property {string} publish_at - The publish date of the news article.
     * @property {boolean} is_active - The status of the news article (active or not).
     */
    const [formData, handleChange] = useForm({
        title: '',
        content: '',
        categoryid: '',  
        authorid: '',
        image: null,
        publish_at: '',
        is_active: true,
    });

    // State to store categories and the loading state
    const [categories, setCategories] = useState([]);
    const [loading, setLoading] = useState(true);

    /**
     * useEffect hook to fetch categories when the component mounts.
     * It calls the categoryService to fetch the categories and set them to state.
     */
    useEffect(() => {
        const fetchCategories = async () => {
            try {
                const categoryList = await categoryService.getAllCategories();
                setCategories(categoryList);
                setLoading(false); 
            } catch (error) {
                console.error('Error fetching categories:', error);
                setLoading(false);
            }
        };
        
        fetchCategories();
    }, []);

    /**
     * Handle form submission.
     * It calls the newsService to create a new news article and then navigates to the admin main page.
     *
     * @param {Event} e - The form submit event.
     */
    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await newsService.createNews(formData);
            console.log('News created:', response);

            navigate('/adminMain');
        } catch (error) {
            console.error('Error creating news:', error);
        }
    };

    return (
        <form onSubmit={handleSubmit} className="create-news-form">
            <div className="form-group">
                <label>Title</label>
                <input
                    type="text"
                    className="form-control"
                    name="title"
                    value={formData.title}
                    onChange={handleChange}
                />
            </div>
            <div className="form-group">
                <label>Content</label>
                <textarea
                    className="form-control"
                    name="content"
                    value={formData.content}
                    onChange={handleChange}
                />
            </div>
            <div className="form-group">
                <label>Category</label>
                {loading ? (
                    <p>Loading categories...</p> 
                ) : (
                    <select
                        className="form-control"
                        name="categoryid"
                        value={formData.categoryid}
                        onChange={handleChange}
                    >
                        <option value="">Select Category</option>
                        {categories.map((category) => (
                            <option key={category.categoryid} value={category.categoryid}>
                                {category.categoryname}
                            </option>
                        ))}
                    </select>
                )}
            </div>
            <div className="form-group">
                <label>Author ID</label>
                <input
                    type="text"
                    className="form-control"
                    name="authorid"
                    value={formData.authorid}
                    onChange={handleChange}
                />
            </div>
            <div className="form-group">
                <label>Publish Date</label>
                <input
                    type="datetime-local"
                    className="form-control"
                    name="publish_at"
                    value={formData.publish_at}
                    onChange={handleChange}
                />
            </div>
            <div className="form-group">
                <label>Image</label>
                <input
                    type="file"
                    className="form-control"
                    name="image"
                    onChange={(e) => handleChange(e)} // Handle image upload
                />
            </div>

            <button type="submit" className="btn btn-primary">
                Create News
            </button>
        </form>
    );
};

// Wrapping CreateNewsForm with requireAuth HOC to ensure only admins can access the page
export default requireAuth(CreateNewsForm, 'admin');
