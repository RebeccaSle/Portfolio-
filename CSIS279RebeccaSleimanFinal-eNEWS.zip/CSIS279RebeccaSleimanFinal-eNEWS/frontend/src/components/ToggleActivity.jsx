import React, { useState} from "react";
import newsService from "../services/newsService";
import useForm from "../hooks/useForm";
import { useNavigate } from "react-router-dom";


const ToggleActivity = ({ newsid, initialIsActive, onStatusChange }) => {
    const [values, handleChange] = useForm({ isActive: initialIsActive }); 
    const [loading, setLoading] = useState(false); 
    const navigate = useNavigate(); 

    const toggleActivity = async () => {
        console.log("Toggling activity for newsid:", newsid);  

        try {
            setLoading(true);
            const newIsActive = values.isActive === 1 ? 0 : 1; 
            const updatedNews = await newsService.updateActivity(newsid, newIsActive); 
            handleChange({ target: { name: "isActive", value: updatedNews.is_active } }); 
            if (onStatusChange) {
                onStatusChange(updatedNews.is_active); 
            }
            if (newIsActive === 1) {
                navigate("/adminMain");
            }
        } catch (error) {
            console.error("Error toggling activity:", error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <button
            onClick={toggleActivity}
            className={`btn ${values.isActive === 1 ? "btn-danger" : "btn-success"}`}
            disabled={loading}
        >
            {loading ? "Processing..." : values.isActive === 1 ? "Deactivate" : "Activate"}
        </button>
    );
};

export default ToggleActivity;
