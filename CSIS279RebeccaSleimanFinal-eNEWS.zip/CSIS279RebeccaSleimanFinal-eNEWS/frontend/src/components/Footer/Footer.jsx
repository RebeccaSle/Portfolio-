import React from 'react';
import './Footer.css';
import { FaFacebookF, FaTwitter, FaInstagram, FaLinkedinIn } from 'react-icons/fa';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-container">
        <div className="footer-content">
          <p>&copy; {new Date().getFullYear()} ENEWS. All rights reserved.</p>
          <p>
            Designed with ❤️ by a computer science student. 
            <a href="/terms" className="footer-link">Terms</a> | 
            <a href="/privacy" className="footer-link">Privacy</a>
          </p>
        </div>
        <div className="footer-socials">
          <a href="https://facebook.com" target="_blank" rel="noreferrer" className="social-link">
            <FaFacebookF />
          </a>
          <a href="https://twitter.com" target="_blank" rel="noreferrer" className="social-link">
            <FaTwitter />
          </a>
          <a href="https://instagram.com" target="_blank" rel="noreferrer" className="social-link">
            <FaInstagram />
          </a>
          <a href="https://linkedin.com" target="_blank" rel="noreferrer" className="social-link">
            <FaLinkedinIn />
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
