import React, { useState, useMemo } from 'react';

const DataGrid = ({ columns, rows, initialSort = { field: '', direction: 'asc' }, rowsPerPage = 5 }) => {
    // State variable to store the sorting configuration, initialized by the initialSort prop
    const [sortConfig, setSortConfig] = useState(initialSort);

    // State variable to store text used for filtering rows based on user input
    const [filterText, setFilterText] = useState('');

    // State variable to track the current page number for paginating rows
    const [currentPage, setCurrentPage] = useState(0);

    // Memoized value for sorted rows:
    // useMemo caches the sorted rows to avoid recalculating sorting each time the component renders,
    // which improves performance. This will only re-calculate when 'rows' or 'sortConfig' change.
    const sortedRows = useMemo(() => {
        // If no field is specified for sorting (sortConfig.field is empty), return rows as-is
        if (!sortConfig.field) return rows;

        // Copy rows into a new array to avoid mutating the original data, then sort
        const sorted = [...rows].sort((a, b) => {
            const aValue = a[sortConfig.field]; 
            const bValue = b[sortConfig.field]; 

            // If sorting in ascending order:
            if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
            if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;

            return 0;
        });

        return sorted;
    }, [rows, sortConfig]);

    // Memoized value for filtered rows:
    // Filtering only recomputes when 'filterText', 'sortedRows', or 'columns' change,
    // which avoids redundant filtering operations, boosting performance.
    const filteredRows = useMemo(() => {
        if (!filterText) return sortedRows;

        return sortedRows.filter(row =>
            columns.some(column => 
                String(row[column.field]).toLowerCase().includes(filterText.toLowerCase())
            )
        );
    }, [filterText, sortedRows, columns]);

    // Memoized value for paginated rows
    // Pagination will re-compute only when 'currentPage', 'rowsPerPage', or 'filteredRows' change.
    // This allows for efficient handling of pagination.
    const paginatedRows = useMemo(() => {
        const start = currentPage * rowsPerPage; 
        const end = start + rowsPerPage; 
        return filteredRows.slice(start, end); 
    }, [currentPage, rowsPerPage, filteredRows]);

    // Updates sorting configuration when a column header is clicked.
    const handleSort = field => {
        setSortConfig(prevConfig => ({
            field,
            direction: prevConfig.field === field && prevConfig.direction === 'asc' ? 'desc' : 'asc'
        }));
    };

    // Updates the current page number when pagination controls are used
    const handlePageChange = (newPage) => setCurrentPage(newPage);

    return (
        <div className="data-grid">
            <input
                type="text"
                placeholder="Search..."
                value={filterText}
                onChange={e => setFilterText(e.target.value)}
                className="data-grid__search"
            />
            <table className="data-grid__table">
                <thead>
                    <tr>
                        {columns.map(column => (
                            <th
                                key={column.field}
                                onClick={() => handleSort(column.field)}
                                className="data-grid__header-cell"
                            >
                                {column.label}
                                {sortConfig.field === column.field && (
                                    <span>{sortConfig.direction === 'asc' ? ' ▲' : ' ▼'}</span>
                                )}
                            </th>
                        ))}
                    </tr>
                </thead>
                <tbody>
                    {paginatedRows.map((row, rowIndex) => (
                        <tr key={rowIndex} className="data-grid__row">
                            {columns.map(column => (
                                <td key={column.field} className="data-grid__cell">
                                    {row[column.field]}
                                </td>
                            ))}
                        </tr>
                    ))}
                </tbody>
            </table>
            <div className="data-grid__pagination">
                <button
                    onClick={() => handlePageChange(currentPage - 1)}
                    disabled={currentPage === 0}
                >
                    Previous
                </button>
                <span>Page {currentPage + 1}</span>
                <button
                    onClick={() => handlePageChange(currentPage + 1)}
                    disabled={(currentPage + 1) * rowsPerPage >= filteredRows.length}
                >
                    Next
                </button>
            </div>
        </div>
    );
};

export default DataGrid;