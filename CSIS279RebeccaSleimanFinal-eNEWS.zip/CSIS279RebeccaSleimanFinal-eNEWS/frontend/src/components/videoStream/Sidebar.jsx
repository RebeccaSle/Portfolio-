import React from "react";

const Sidebar = () => {
  return (
    <div className="sidebar">
      <h3>Streaming Logic Here(needs css and better displaying)</h3>
    </div>
  );
};

export default Sidebar;
