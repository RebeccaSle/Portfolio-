import React, { useEffect, useRef } from "react";
import { useSocket } from "../../Context/Context";

const UserVideoStream = () => {
  const { joinStream, remoteStream, socketConnected } = useSocket();
  const videoRef = useRef();

  useEffect(() => {
    if (remoteStream) {
      videoRef.current.srcObject = remoteStream; 
      console.log("Remote stream set to video element.");
    } else {
      console.log("No remote stream available.");
    }
  }, [remoteStream]);

  const handleJoinStream = () => {
    if (socketConnected) {
      joinStream(); 
      console.log("Joining the stream...");
    } else {
      console.error("Socket not connected!");
    }
  };

  return (
    <div className="user-video-stream">
      <h2>User Video Stream</h2>
      <div style={{ width: "100%", maxWidth: "640px", margin: "0 auto" }}>
        <video
          ref={videoRef}
          autoPlay
          playsInline
          controls={false}
          style={{
            width: "100%",
            height: "360px",
            backgroundColor: "#000", 
          }}
        />
      </div>
      <button onClick={handleJoinStream} disabled={!socketConnected}>
        Join Stream
      </button>
    </div>
  );
};

export default UserVideoStream;
