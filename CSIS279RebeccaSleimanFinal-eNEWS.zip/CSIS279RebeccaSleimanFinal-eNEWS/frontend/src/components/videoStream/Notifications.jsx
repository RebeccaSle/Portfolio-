import React from "react";

const Notifications = ({ message }) => {
  return <div className="notifications">{message && <p>{message}</p>}</div>;
};

export default Notifications;
