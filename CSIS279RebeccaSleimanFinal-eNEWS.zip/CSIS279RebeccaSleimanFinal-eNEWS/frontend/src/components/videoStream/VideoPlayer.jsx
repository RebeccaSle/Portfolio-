import React from "react";
import useMediaStream from "../../hooks/useMediaStream";

const VideoPlayer = ({ onEndStream }) => {
  const { videoRef, isCameraOn, isMicOn, startCamera, stopCamera, toggleMic } = useMediaStream();

  const handleStopCamera = () => {
    stopCamera();
    if (onEndStream) {
      onEndStream();
    }
  };

  return (
    <div className="video-player">
      <div className="video-container">
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted={!isMicOn} 
          style={{
            width: "100%",
            height: "auto",
            border: "1px solid #ccc",
            borderRadius: "8px",
            backgroundColor: "#000",
          }}
        />
      </div>

      <div className="controls">
        {!isCameraOn ? (
          <button onClick={startCamera}>Start Camera</button>
        ) : (
          <button onClick={handleStopCamera}>Stop Camera</button>
        )}
        <button onClick={toggleMic}>
          {isMicOn ? "Mute Mic" : "Unmute Mic"}
        </button>
      </div>
    </div>
  );
};

export default VideoPlayer;
