import React, { useState, useEffect } from "react";
import { useSocket } from "../../Context/Context";
import requireAuth from "../../hoc/requireAuth";
import VideoPlayer from "../../components/videoStream/VideoPlayer"; 

const AdminVideoStream = () => {
  const { startStream, stopStream, socketConnected } = useSocket();
  const [localStream, setLocalStream] = useState(null);

  const handleEndStream = () => {
    stopStream(); 
    if (localStream) {
      localStream.getTracks().forEach((track) => track.stop()); 
      setLocalStream(null); 
    }
  };

  useEffect(() => {
    const initStream = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: true,
        });
        setLocalStream(stream); 
      } catch (error) {
        console.error("Error accessing camera and microphone:", error);
      }
    };

    if (!localStream) {
      initStream(); 
    }

    return () => {
      if (localStream) {
        localStream.getTracks().forEach((track) => track.stop()); 
      }
    };
  }, [localStream]); 

  return (
    <div className="admin-video-stream">
      <h2>Admin Video Stream</h2>
      <VideoPlayer onEndStream={handleEndStream} />
      <button onClick={startStream} disabled={!socketConnected}>
        Start Stream
      </button>
      <button onClick={handleEndStream}>End Stream</button>
    </div>
  );
};

export default requireAuth(AdminVideoStream, "admin");
