import React from 'react';
import { Dropdown } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import { clearToken, decodeToken } from '../../utils/Utils'; 
import './header.css';

const Header = () => {
  const navigate = useNavigate(); 

  const handleLogout = () => {
    clearToken(); 
    navigate('/', { replace: true }); 
  };

  const handleMainPage = () => {
    const token = localStorage.getItem('token'); 
    const user = token ? decodeToken(token) : null; 

    if (user && user.role) {
      if (user.role === 'admin') {
        navigate('/adminMain'); 
      } else if (user.role === 'user') {
        navigate('/userMain'); 
      } else {
        console.error('Unknown user role:', user.role); 
      }
    } else {
      console.error('Invalid or missing token');
      navigate('/', { replace: true }); 
    }
  };

  return (
    <header className="header-container">
      <div className="container d-flex justify-content-between align-items-center">
        {/* Dropdown Menu */}
        <Dropdown>
          <Dropdown.Toggle variant="success" id="dropdown-basic" className="dropdown-toggle">
            Account
          </Dropdown.Toggle>

          <Dropdown.Menu className="dropdown-menu">
            <Dropdown.Item href='/manageAccount'>Manage Account</Dropdown.Item>
            <Dropdown.Item onClick={handleLogout}>Logout</Dropdown.Item> 
            <Dropdown.Item onClick={handleMainPage}>Main Page</Dropdown.Item> 
          </Dropdown.Menu>
        </Dropdown>

        <h1 className="header-text">
          eNews, <span className="header-subtext">your trusted source of information</span>
        </h1>
      </div>
    </header>
  );
};

export default Header;
