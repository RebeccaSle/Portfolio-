import React from "react";
import { useNavigate } from "react-router-dom"; 

const Button = ({ text, url }) => {
    const navigate = useNavigate();

    const handleClick = () => {
        if (url) {
            navigate(url); 
        }
    };

    return (
        <button onClick={handleClick} className="btn">
            {text}
        </button>
    );
};

export default Button;
