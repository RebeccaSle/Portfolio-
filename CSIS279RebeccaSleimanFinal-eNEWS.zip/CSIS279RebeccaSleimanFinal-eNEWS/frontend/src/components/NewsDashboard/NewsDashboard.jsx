import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import newsService from "../../services/newsService";
import "./NewsDashboard.css";

const NewsDashboard = () => {
    const [news, setNews] = useState([]);
    const [searchQuery, setSearchQuery] = useState("");
    const [error, setError] = useState(null);
    const [currentPage, setCurrentPage] = useState(1);
    const articlesPerPage = 8;
    const navigate = useNavigate();

    useEffect(() => {
        const fetchNews = async () => {
            try {
                const response = await newsService.getNewsByActivity(1);
                setNews(response.news);
            } catch (err) {
                setError("Failed to fetch news.");
            }
        };

        fetchNews();
    }, []);

    const filteredNews = news.filter((item) =>
        item.title?.toLowerCase().includes(searchQuery.toLowerCase())
    );
    
    const totalPages = Math.ceil(filteredNews.length / articlesPerPage);
    const indexOfLastArticle = currentPage * articlesPerPage;
    const indexOfFirstArticle = indexOfLastArticle - articlesPerPage;
    const currentNews = filteredNews.slice(indexOfFirstArticle, indexOfLastArticle);
    
    const handlePrevPage = () => setCurrentPage((prev) => Math.max(prev - 1, 1));
    const handleNextPage = () => setCurrentPage((prev) => Math.min(prev + 1, totalPages));

    const handleClickNews = (id) => navigate(`/news/${id}`);

    if (error) {
        return <p>{error}</p>;
    }

    return (
        <div className="news-dashboard">
            <h2>News Dashboard</h2>
            <input
                type="text"
                placeholder="Search news"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="news-dashboard__search"
            />
            {currentNews.length > 0 ? (
                <ul className="news-list">
                    {currentNews.map((item) => (
                        <li
                            key={item.newsid}
                            className="news-item"
                            onClick={() => handleClickNews(item.newsid)}
                        >
                            {item.Image && (
                                <img
                                    src={`http://localhost:3001${item.Image}`}
                                    alt={item.title || "News Image"}
                                    className="news-image"
                                />
                            )}
                            <h3>{item.title || "Untitled Article"}</h3>
                        </li>
                    ))}
                </ul>
            ) : (
                <p>No news available.</p>
            )}
            <div className="pagination">
                <button
                    onClick={handlePrevPage}
                    disabled={currentPage === 1}
                    className="pagination-button"
                >
                    Previous
                </button>
                <span>
                    {currentPage} / {totalPages}
                </span>
                <button
                    onClick={handleNextPage}
                    disabled={currentPage === totalPages}
                    className="pagination-button"
                >
                    Next
                </button>
            </div>
        </div>
    );
};

export default NewsDashboard;
