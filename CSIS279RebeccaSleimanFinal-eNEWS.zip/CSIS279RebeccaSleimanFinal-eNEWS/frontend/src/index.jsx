import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import '../src/index.css';
import './pages/RegisterPage/RegisterPage.css';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
