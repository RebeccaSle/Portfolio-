import axios from "axios";

const API_BASE_URL = "http://localhost:3001/api/category"; 

const categoryService = {
    // Fetch all categories
    getAllCategories: async () => {
        try {
            const response = await axios.get(`${API_BASE_URL}`);
            return response.data;
        } catch (error) {
            console.error("Error fetching categories:", error);
            throw error.response?.data?.message || "Failed to fetch categories.";
        }
    },

    // Fetch a category by ID
    getCategoryById: async (id) => {
        try {
            const response = await axios.get(`${API_BASE_URL}/${id}`);
            return response.data; 
        } catch (error) {
            console.error(`Error fetching category with ID ${id}:`, error);
            throw error.response?.data?.message || `Failed to fetch category with ID ${id}.`;
        }
    },

    // Create a new category
    createCategory: async (categoryData) => {
        try {
            const response = await axios.post(`${API_BASE_URL}`, categoryData);
            return response.data; 
        } catch (error) {
            console.error("Error creating category:", error);
            throw error.response?.data?.message || "Failed to create category.";
        }
    },

    // Update an existing category by ID
    updateCategory: async (id, categoryData) => {
        try {
            const response = await axios.put(`${API_BASE_URL}/${id}`, categoryData);
            return response.data; 
        } catch (error) {
            console.error(`Error updating category with ID ${id}:`, error);
            throw error.response?.data?.message || `Failed to update category with ID ${id}.`;
        }
    },

    // Delete a category by ID
    deleteCategory: async (id) => {
        try {
            const response = await axios.delete(`${API_BASE_URL}/${id}`);
            return response.data; 
        } catch (error) {
            console.error(`Error deleting category with ID ${id}:`, error);
            throw error.response?.data?.message || `Failed to delete category with ID ${id}.`;
        }
    }
};

export default categoryService;
