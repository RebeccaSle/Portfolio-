import axios from 'axios';
import { saveToken, getTokenBearer } from '../utils/Utils';

// i could have set it globally since i am using it in many files
const API_BASE_URL = 'http://localhost:3001/api/users';

// Fetch all users
export const getUsers = async () => {
  const API_URL = `${API_BASE_URL}/all`;

  try {
    const token = getTokenBearer(); 
    const response = await axios.get(API_URL, {
      headers: {
        Authorization: token, 
      },
    });

    console.log(response.data); 
    return response.data.users; 
  } catch (error) {
    console.error('Error fetching users:', error);
    throw error;
  }
};

// Register a new user
export const registerUser = async (username, email, password, phone) => {
  const API_URL = `${API_BASE_URL}/auth/register`;

  try {
    const response = await axios.post(API_URL, {
      username,
      email,
      password,
      phone,
    });

    console.log(response.data); 

    // Save the token to localStorage if registration is successful
    if (response.data.token) {
      saveToken(response.data.token);
    }

    return response.data; 
  } catch (error) {
    console.error('Error during registration:', error);
    throw error; 
  }
};

// Authenticate user and log in
export const loginUser = async (username, password) => {
  const API_URL = `${API_BASE_URL}/auth/login`;

  try {
    console.log('Sending login request with:', { username, password });

    const response = await axios.post(API_URL, {
      username,
      password,
    });

    console.log('Login response:', response.data);

    if (response.data.token) {
      saveToken(response.data.token);
    }

    return response.data; 
  } catch (error) {
    console.error('Error during login:', error);
    throw error;
  }
};

export const updateUser = async (userId, userData) => {
  const API_URL = `${API_BASE_URL}/${userId}`;

  try {
    const token = getTokenBearer(); 

    const response = await axios.put(API_URL, userData, {
      headers: {
        'Content-Type': 'application/json',
        Authorization: token, 
      },
    });

    return response.data;
  } catch (error) {
    console.error('Error updating user:', error);
    throw error; 
  }
};

