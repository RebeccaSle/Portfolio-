import axios from "axios";
const API_BASE_URL = "http://localhost:3001/api/news"; 

const newsService = {
    getAllNews: async () => {
        try {
            const response = await axios.get(`${API_BASE_URL}`);
            
            return response.data;
        } catch (error) {
            console.error("Error fetching news:", error);
            throw error;
        }
    },

    getNewsByActivity: async (isActive) => {
        try {
            const response = await axios.get(`${API_BASE_URL}/activity/${isActive}`);
            return response.data;
        } catch (error) {
            console.error(`Error fetching news by activity status (${isActive}):`, error);
            throw error;
        }
    },
    
    getNewsById: async (id) => {
        try {
            const response = await axios.get(`${API_BASE_URL}/${id}`);
            return response.data;
        } catch (error) {
            console.error(`Error fetching news with ID ${id}:`, error);
            throw error;
        }
    },

    createNews: async (newsData) => {
        try {
            const response = await axios.post(API_BASE_URL, newsData);
            return response.data; 
        } catch (error) {
            console.error("Error creating news:", error);
            throw error.response?.data?.message || "Failed to create news.";
        }
    },

    updateActivity: async (newsid, isActive) => {
        try {
            const response = await axios.put(`${API_BASE_URL}/${newsid}`, { is_active: isActive });
            return response.data;
        } catch (error) {
            console.error("Error updating activity:", error);
            throw error;
        }
    },
    
};

export default newsService;
