import React, { createContext, useState, useEffect, useContext } from "react";
import { io } from "socket.io-client";

const SocketContext = createContext();
const socket = io("http://localhost:3001", {
  query: { token: localStorage.getItem("token") },
});

export const SocketProvider = ({ children }) => {
  const [socketConnected, setSocketConnected] = useState(false);
  const [peerConnection, setPeerConnection] = useState(null); // WebRTC peer connection
  const [remoteStream, setRemoteStream] = useState(null); // Stream for user

  useEffect(() => {
    socket.on("connect", () => {
        console.log("Socket connected:", socket.id);  // Check if client connect to the server
        setSocketConnected(true);
      });
          socket.on("disconnect", () => setSocketConnected(false));

    // WebRTC signaling
    socket.on("offer", async (offer) => {
      const peer = new RTCPeerConnection();
      setPeerConnection(peer);

      peer.ontrack = (event) => {
        setRemoteStream(event.streams[0]); 
      };

      await peer.setRemoteDescription(offer); 
      const answer = await peer.createAnswer();
      await peer.setLocalDescription(answer);

      socket.emit("answer", answer); // Send answer  to admin
    });

    socket.on("ice-candidate", async (candidate) => {
      if (peerConnection) {
        await peerConnection.addIceCandidate(candidate); //ICE candidates
      }
    });

    // Listen for the streamStarted event
    socket.on("streamStarted", (data) => {
      console.log("Stream started event received:", data);
      console.log(`Stream started by broadcaster with ID: ${data.broadcasterId}`);
    });

    // Listen for the streamEnded event
    socket.on("streamEnded", (data) => {
      console.log("Stream ended event received:", data);
      console.log(`Stream ended by broadcaster with ID: ${data.broadcasterId}`);
    });

    return () => {
      socket.off("offer");
      socket.off("ice-candidate");
      socket.off("streamStarted");
      socket.off("streamEnded");  
    };
  }, [peerConnection]);

  const startStream = () => {
    console.log('Start stream button clicked');
    socket.emit("broadcaster");
  };

  const stopStream = () => {
    console.log('Stop stream button clicked');
    socket.emit("stopBroadcast");
    if (peerConnection) {
      peerConnection.close();
      setPeerConnection(null);
    }
    setRemoteStream(null);
  };

  const joinStream = () => {
    socket.emit("watcher");
  };

  return (
    <SocketContext.Provider
      value={{
        socket,
        startStream,
        stopStream,
        joinStream,
        remoteStream,
        socketConnected,
      }}
    >
      {children}
    </SocketContext.Provider>
  );
};

export const useSocket = () => useContext(SocketContext);
