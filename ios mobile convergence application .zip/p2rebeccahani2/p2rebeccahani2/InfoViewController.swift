//
//  InfoViewController.swift
//  p2rebeccahani2
//
//  Created by csis on 5/9/24.
//  Copyright © 2024 csis. All rights reserved.
//

import UIKit

class InfoViewController: UIViewController {
    
    @IBOutlet weak var countlabel: UILabel!
    
    
    var count = UserDefaults.standard.integer(forKey: "nbofuser")

    override func viewDidLoad() {
        super.viewDidLoad()
     
        
        updateounterlabel()
        countlabel.text = " the number of time entered \(count)"
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
        
        
        
        // Do any additional setup after loading the view.
    
   
    func updateounterlabel(){
        count = count+1
        UserDefaults.standard.set(count, forKey: "nbofuser")
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
