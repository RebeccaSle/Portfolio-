//
//  TempViewController.swift
//  p2rebeccahani2
//
//  Created by csis on 5/9/24.
//  Copyright © 2024 csis. All rights reserved.
//

import UIKit

class TempViewController: UIViewController ,UIPickerViewDelegate, UIPickerViewDataSource {
    

    @IBOutlet weak var highesttemp: UILabel!
    @IBOutlet weak var fromslider: UIPickerView!
    private let from = [
        "celcius", "farheheite "]
    private let to = [
        "celcius", "farheheite "]
    
    @IBOutlet weak var topicker: UIPickerView!
    @IBOutlet weak var numbertoconverge: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
        let skey2 = UserDefaults.standard.float(forKey:"highestnbtemp")
        highesttemp.text="The highest converged value is \(skey2)"

        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        view.addGestureRecognizer(tapGesture)
    }
    
    // Function to dismiss the keyboard
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    
    @IBAction func Convergebtn2(_ sender: UIButton) {
        let row = fromslider.selectedRow(inComponent: 0)
        let selected = from[row]
        let row2 = topicker.selectedRow(inComponent: 0)
        let selected2 = to[row2]
        let inputvalue = Float(numbertoconverge.text!) ?? 0
        var convertedvaluetemp: Float = 0
        
        if selected == "celcius" && selected2 == "celcius" ||
            selected == "farheheite " && selected2 == "farheheite " {
            convertedvaluetemp = inputvalue
        }
        
        if selected == "celcius" && selected2 == "farheheite " {
            convertedvaluetemp = (inputvalue * 9/5) + 32 // Celsius to Fahrenheit
        }
        
        if selected == "farheheite " && selected2 == "celcius" {
            convertedvaluetemp = (inputvalue - 32) * 5/9 // Fahrenheit to Celsius
        }
        let controller1 = UIAlertController(title:"your value have been converged to\(convertedvaluetemp) ", message:nil, preferredStyle: .actionSheet)
        let closeaction1  = UIAlertAction(title: "ok" , style: .cancel, handler: nil)
        controller1.addAction(closeaction1)
        self.present(controller1,animated: true,completion: nil)
        
        var highestnbtemp = UserDefaults.standard.float(forKey: "highestnbtemp")
        if (convertedvaluetemp > highestnbtemp) {
            highestnbtemp = convertedvaluetemp
            highesttemp.text="The highest converged value is \(highestnbtemp)"
            UserDefaults.standard.set(highestnbtemp, forKey: "highestnbtemp")
    }
        
    
    }
    @IBAction func tap(_ sender: AnyObject) {
        numbertoconverge.resignFirstResponder()
    }
    // MARK:-
    // MARK: Picker Data Source Methods
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView,
                    numberOfRowsInComponent component: Int) -> Int {
        return from.count
    }
    // MARK: Picker Delegate Methods
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component:
        Int) -> String? {
        return from[row]
    }
    
    func numberOfComponents2(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView2(_ pickerView: UIPickerView,
                    numberOfRowsInComponent component: Int) -> Int {
        return to.count
    }
    // MARK: Picker Delegate Methods
    func pickerView2(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component:
        Int) -> String? {
        return to[row]
    }

     /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
