//
//  WeightViewController.swift
//  p2rebeccahani2
//
//  Created by csis on 5/9/24.
//  Copyright © 2024 csis. All rights reserved.
//

import UIKit

class WeightViewController: UIViewController {

    @IBOutlet weak var fromslider: UISlider!
    @IBOutlet weak var numbertoconverge: UITextField!
    @IBOutlet weak var highest: UILabel!
    @IBOutlet weak var toslider: UISlider!
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        let skey = UserDefaults.standard.float(forKey:"highestnb")
        highest.text="The highest coverged value is \(skey)"

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func convergebtn(_ sender: UIButton) {
        let fromvalue = lroundf(fromslider.value)
        let tovalue = lroundf(toslider.value)
        let inputvalue = Float(numbertoconverge.text!) ?? 0
        let power = pow(10,Float(tovalue-fromvalue))
        let convertedvalue = inputvalue*power
        let controller = UIAlertController(title:"your value have been converged to\(convertedvalue) ", message:nil, preferredStyle: .actionSheet)
        let closeaction  = UIAlertAction(title: "ok" , style: .cancel, handler: nil)
        controller.addAction(closeaction)
        self.present(controller,animated: true,completion: nil)
        
        var highestnb = UserDefaults.standard.float(forKey: "highestnb")
        if (convertedvalue > highestnb) {
            highestnb = convertedvalue
            highest.text="The highest converged value is \(highestnb)"
            UserDefaults.standard.set(highestnb, forKey: "highestnb")
            
        }
   

}
    @IBAction func tap(_ sender: AnyObject) {
        numbertoconverge.resignFirstResponder()
    }
}
