//
//  DateViewController.swift
//  p2rebeccahani2
//
//  Created by csis on 5/9/24.
//  Copyright © 2024 csis. All rights reserved.
//

import UIKit

class DateViewController: UIViewController , UIPickerViewDelegate, UIPickerViewDataSource {
    @IBOutlet weak var single: UIPickerView!
    @IBOutlet weak var datepicker: UIDatePicker!
    private let country = [
        "Lebanon",  "china ","uk","germany"]

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func date(_ sender: UIButton) {
        var date = datepicker.date
        let row = single.selectedRow(inComponent: 0)
        let selected = country[row]
        
        if selected == "Lebanon" {
            date.addTimeInterval(3*3600)}
        else if selected == "china" {
            date.addTimeInterval(7*3600)
        }
        else if selected == "uk" {
            date.addTimeInterval(0*3600)
        }
        else if selected == "germany" {
            date.addTimeInterval(1*3600)
        }
        let message = "The date and time you selected is \(date)"
        let alert = UIAlertController(
            title: "Date and Time Selected",
            message: message,
            preferredStyle: .alert)
        let action = UIAlertAction(
            title: "That's so true!",
            style: .default,
            handler: nil)
        alert.addAction(action)
        present(alert, animated: true, completion: nil)

    }


// MARK:-
// MARK: Picker Data Source Methods
func numberOfComponents(in pickerView: UIPickerView) -> Int {
    return 1
}
func pickerView(_ pickerView: UIPickerView,
                numberOfRowsInComponent component: Int) -> Int {
    return country.count
}
// MARK: Picker Delegate Methods
func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component:
    Int) -> String? {
    return country[row]
}

}

