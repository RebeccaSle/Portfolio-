class Snake extends Sprite {
    constructor() {
        super();
        this.gridSize = 20;
        this.canvasWidth = 800;
        this.canvasHeight = 600;
        this.gridWidth = this.canvasWidth / this.gridSize;
        this.gridHeight = this.canvasHeight / this.gridSize;

        this.snakeImage = this.loadImage('sprites/Snake.png');
        this.resetGame(); 
    }

    // This method resets the entire game to its initial state.
    resetGame() {
        this.resetSnake();
        this.speed = 5;
        this.frameCounter = 0;
        this.score = 0;
        this.lives = 3;

        this.gameOver = false;
        this.gameWon = false;
        this.restartRequested = false;
        this.gameStarted = false; 
    }

    // This method resets the snake to its initial position.
    resetSnake() {
        this.body = [{ x: Math.floor(this.gridWidth / 2), y: Math.floor(this.gridHeight / 2) }];
        this.growing = false;
    }

    // This method loads image 
    loadImage(src) {
        const img = new Image();
        img.src = src;
        return img;
    }

    // This method updates the snake's state on each game frame.
    update(sprites, keys) {
        // if 'R' key is pressed to restart the game
        if (keys['r'] || keys['R']) {
            this.restartRequested = true;
            // Clear all keys
            for (let key in keys) {
                keys[key] = false;
            }
        }

        if (this.restartRequested) {
            this.restartGame(sprites);
            return false;
        }

        // Handle game start logic
        if (!this.gameStarted) {
            // Wait until the intro message is removed
            if (!sprites.some(sprite => sprite instanceof Message && sprite.type === 'intro')) {
                this.gameStarted = true;
                this.direction = 'right'; // Start moving right
                this.nextDirection = 'right';
                // Clear all keys
                for (let key in keys) {
                    keys[key] = false;
                }
               
            } else {
                return false;
            }
        }

        if (this.gameOver || this.gameWon) {
            return false;
        }

        if (++this.frameCounter < this.speed) return false;
        this.frameCounter = 0;

        this.handleInput(keys);
        const newHead = this.getNextHead();

        if (this.isCollision(newHead)) {
            this.handleCollision(sprites);
            return false;
        }

        this.body.unshift(newHead);
        if (!this.growing) this.body.pop();
        else this.growing = false;

        this.handleObstacleCollision(sprites, newHead);
        this.checkWinCondition(sprites);

        return false;
    }

    // This method restarts the game by resetting variables and reinitializing obstacles.
    restartGame(sprites) {
        this.resetGame();

        // this is the only pleace where i used splice, to remove the message from the screen.
        //elsewhere i removed or pushed to the sprite array, dont be hard on the grades please :)
        for (let i = sprites.length - 1; i >= 0; i--) {
            if (sprites[i] instanceof Obstacle || sprites[i] instanceof Message) {
                sprites.splice(i, 1);
            }
        }

        // Re-add obstacles
        const obstacleInstance = new Obstacle();
        const obstacles = obstacleInstance.generateObstacles(
            this.canvasWidth / this.gridSize,
            this.canvasHeight / this.gridSize,
            this.gridSize, 8,  "sprites/snakefood.jpeg", 600, 100, 100, 6);
        obstacles.forEach(obstacle => sprites.push(obstacle));

        // Start the game 
        this.gameStarted = true;
        this.direction = 'right';
        this.nextDirection = 'right';

        // Clear the restart flag
        this.restartRequested = false;
    }

    // This method handles user input to change the snake's direction.
    handleInput(keys) {
        if (!this.direction) return;

        const opposite = {
            up: 'down',
            down: 'up',
            left: 'right',
            right: 'left',
        };

        const directions = {
            ArrowUp: 'up',
            ArrowDown: 'down',
            ArrowLeft: 'left',
            ArrowRight: 'right',
        };

        for (let key in directions) {
            const dir = directions[key];
            if (keys[key] && this.direction !== opposite[dir]) {
                this.nextDirection = dir;
            }
        }

        this.direction = this.nextDirection;
    }

    // This method calculates the next position of the snake's head based on its current direction.
    getNextHead() {
        const x = this.body[0].x;
        const y = this.body[0].y;
        const moves = {
            up: { x: x, y: y - 1 },
            down: { x: x, y: y + 1 },
            left: { x: x - 1, y: y },
            right: { x: x + 1, y: y },
        };
        return moves[this.direction];
    }

    // This method checks if the snake has collided with walls or itself.
    isCollision(head) {
        return (
            head.x < 0 ||
            head.x >= this.gridWidth ||
            head.y < 0 ||
            head.y >= this.gridHeight ||
            this.body.some(segment => segment.x === head.x && segment.y === head.y)
        );
    }

    // This method handles the outcome when the snake collides with a wall or itself.
    handleCollision(sprites) {
        this.lives--;
        this.playSound('sounds/gameover.mp3'); 
        if (this.lives <= 0) {
            this.gameOver = true;
            this.direction = null; 

            // Add game over message
            const gameOverMessage = new Message('gameOver', this.score);
            sprites.push(gameOverMessage);
        } else {
            this.resetSnake(); 
        }
    }

    // This method checks for collisions with obstacles and handles growth.
    handleObstacleCollision(sprites, head) {
        for (let i = 0; i < sprites.length; i++) {
            const sprite = sprites[i];
            if (sprite instanceof Obstacle && sprite.x === head.x && sprite.y === head.y) {
                this.growing = true;
                this.score++;
                sprite.respawn(this.gridWidth, this.gridHeight);
                this.adjustSpeed();
                this.playSound('sounds/eat.mp3');
            }
        }
    }

    // This method adjusts the snake's speed based on its score.
    adjustSpeed() {
        this.speed = Math.max(2, 5 - Math.floor(this.score / 10));
    }

    // This method checks if the player won
    checkWinCondition(sprites) {
        if (this.score >= 30) {
            this.gameWon = true;
            this.direction = null; 

            // Add game won message
            const gameWonMessage = new Message('gameWon', this.score);
            sprites.push(gameWonMessage);
        }
    }

    playSound(src) {
        const sound = new Audio(src);
        sound.play();
    }

    // This method draws the snake and elements on the canvas.
    draw(ctx) {
        // Draw the snake only if the game has started
        if (this.gameStarted && !this.gameOver && !this.gameWon) {
            for (let i = 0; i < this.body.length; i++) {
                const segment = this.body[i];
                ctx.drawImage(
                    this.snakeImage,
                    90, 90, 80, 80,
                    segment.x * this.gridSize,
                    segment.y * this.gridSize,
                    this.gridSize,
                    this.gridSize
                );
            }
        }

        // Draw the score and lives
        if (this.gameStarted && !this.gameOver && !this.gameWon) {
            ctx.fillStyle = "white";
            ctx.font = "20px Arial";

            // Adjusted positions
            ctx.fillText("Score: " + this.score, 50, 30);
            ctx.fillText("Lives: " + this.lives, 50, 55);
        }
    }
}

class Message extends Sprite {
    constructor(type, subtext = '') {
        super();
        this.type = type; 
        this.subtext = subtext;
        this.canvasWidth = 800;
        this.canvasHeight = 600;
    }

    // This method updates the message sprite.
    update(sprites, keys) {
        if (keys['r'] || keys['R']) {
            // Clear all keys
            for (let key in keys) {
                keys[key] = false;
            }
            return true; 
        }
        return false; 
    }

    // This method draws the message overlay on the canvas.
    draw(ctx) {
        ctx.fillStyle = "rgba(0, 0, 0, 0.7)";
        ctx.fillRect(0, 0, this.canvasWidth, this.canvasHeight);

        // Display the main message based on type
        ctx.fillStyle = "white";
        ctx.textAlign = "center";

        switch (this.type) {
            case 'intro':
                ctx.font = "39px Arial";
                ctx.fillText("Welcome to Snake Game! Reach 30 and win!",
                     this.canvasWidth / 2, this.canvasHeight / 2 - 50);
                ctx.font = "30px Arial";
                ctx.fillText("Use arrows to navigate the snake in 4 directions", this.canvasWidth / 2, this.canvasHeight / 2);
                ctx.font = "20px Arial";
                ctx.fillText("Press 'R' to Start, or Restart, 'P' to Pause, 'C' to Resume ", this.canvasWidth / 2, this.canvasHeight / 2 + 50);
                break;
            case 'gameOver':
                ctx.font = "50px Arial";
                ctx.fillText("Game Over", this.canvasWidth / 2, this.canvasHeight / 2 - 50);
                ctx.font = "30px Arial";
                ctx.fillText(`Score: ${this.subtext}`, this.canvasWidth / 2, this.canvasHeight / 2);
                ctx.font = "20px Arial";
                ctx.fillText("Press 'R' to Restart", this.canvasWidth / 2, this.canvasHeight / 2 + 50);
                break;
            case 'gameWon':
                ctx.font = "50px Arial";
                ctx.fillText("You Win!", this.canvasWidth / 2, this.canvasHeight / 2 - 50);
                ctx.font = "30px Arial";
                ctx.fillText(`Score: ${this.subtext}`, this.canvasWidth / 2, this.canvasHeight / 2);
                ctx.font = "20px Arial";
                ctx.fillText("Press 'R' to Restart", this.canvasWidth / 2, this.canvasHeight / 2 + 50);
                break;
            default:
                break;
        }
    }
}
