class Background extends Sprite {
    constructor(backgroundImageSrc, backgroundSpeed) {
      super(); 
  
      this.backgroundImage = new Image();
      this.backgroundImage.src = backgroundImageSrc; 
      this.backgroundSpeed = backgroundSpeed; 
      this.backgroundY = 0; 
    }
  
    update() {
      this.backgroundY += this.backgroundSpeed;
  
      if (this.backgroundY >= canvas.height) {
        this.backgroundY = 0;
      }
    }
  
    draw(ctx) {
      ctx.drawImage(
        this.backgroundImage,
        0,
        this.backgroundY,
        canvas.width,
        canvas.height
      );
  
      ctx.drawImage(
        this.backgroundImage,
        0,
        this.backgroundY - canvas.height,
        canvas.width,
        canvas.height
      );
    }
  }
  