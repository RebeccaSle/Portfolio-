class Obstacle extends Sprite {
    constructor(imagePath, x, y, gridSize, width, height, timePerFrame, numberOfFrames) {
        super();

        // Load the obstacle sprite sheet
        this.spritesheet = new Image();
        this.spritesheet.src = imagePath;

        this.x = x;
        this.y = y;
        this.gridSize = gridSize;

        this.width = width;  
        this.height = height; 
        this.timePerFrame = timePerFrame;  
        this.numberOfFrames = numberOfFrames || 1; 
        this.frameIndex = 0; 
        this.lastUpdate = Date.now();  
    }

    //randomly add new obstacles in the grid much fun and unpredictable where to eat next 

    respawn(gridWidth, gridHeight) {
        this.x = Math.floor(Math.random() * gridWidth);
        this.y = Math.floor(Math.random() * gridHeight);
    }

    update() {
        if (Date.now() - this.lastUpdate >= this.timePerFrame) {
            this.frameIndex++;
            if (this.frameIndex >= this.numberOfFrames) {
                this.frameIndex = 0;
            }
            this.lastUpdate = Date.now();
        }
    }

    draw(ctx) {
        ctx.drawImage(
            this.spritesheet,
            this.frameIndex * (this.width / this.numberOfFrames), 
            0,  
            this.width / this.numberOfFrames,  
            this.height,  
            this.x * this.gridSize,  
            this.y * this.gridSize,  
            this.gridSize,  // Width to draw (scaled to grid size)
            this.gridSize  
        );
    }

    generateObstacles(gridWidth, gridHeight, gridSize, numberOfObstacles, imagePath, width, height, timePerFrame, numberOfFrames) {
        let obstacles = [];
        for (let i = 0; i < numberOfObstacles; i++) {
            let x = Math.floor(Math.random() * gridWidth);
            let y = Math.floor(Math.random() * gridHeight);
            let obstacle = new Obstacle(imagePath, x, y, gridSize, width, height, timePerFrame, numberOfFrames);
            obstacles.push(obstacle);
        }
        return obstacles;
    }
}
