const myGame = new Game();

const background = new Background("./sprites/background.jpeg", 2);
myGame.addSprite(background);

const snake = new Snake();
myGame.addSprite(snake);

const obstacleInstance = new Obstacle();
const obstacles = obstacleInstance.generateObstacles(
    snake.canvasWidth / snake.gridSize,
    snake.canvasHeight / snake.gridSize,
    snake.gridSize,
    8,  // Number of obstacles
    "sprites/snakefood.jpeg",
    600,
    100,
    100,
    6
);

obstacles.forEach(obstacle => myGame.addSprite(obstacle));

const introMessage = new Message('intro');
myGame.addSprite(introMessage);

myGame.animate();
